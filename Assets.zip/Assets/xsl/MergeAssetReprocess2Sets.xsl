<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:common="urn:epcor:as:Common" exclude-result-prefixes="xsl types xsd bpws xp20 xref orcl ora hwf ids dvm common" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
                
  <xsl:param name="newAssets"/>
  <xsl:param name="processControl"/>
 
  <xsl:template match="/">
    
    <data:AssetReprocessSet>
      <data:Poles>
        <xsl:for-each select="data:AssetReprocessSet/data:Poles/data:Pole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Poles/data:Pole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Poles>

	   <data:TransPoles>
        <xsl:for-each select="data:AssetReprocessSet/data:TransPoles/data:TransPole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:TransPoles/data:TransPole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:TransPoles>
      <data:TransStructures>
        <xsl:for-each select="data:AssetReprocessSet/data:TransStructures/data:TransStructure">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:TransStructures/data:TransStructure">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:TransStructures>
      <data:Pads>
        <xsl:for-each select="data:AssetReprocessSet/data:Pads/data:Pad">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Pads/data:Pad">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Pads>
      <data:Pedestals>
        <xsl:for-each select="data:AssetReprocessSet/data:Pedestals/data:Pedestal">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Pedestals/data:Pedestal">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Pedestals>
      <data:DecorativePoles>
        <xsl:for-each select="data:AssetReprocessSet/data:DecorativePoles/data:DecorativePole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:DecorativePoles/data:DecorativePole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:DecorativePoles>
      <data:AerialWires>
        <xsl:for-each select="data:AssetReprocessSet/data:AerialWires/data:AerialWire">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:AerialWires/data:AerialWire">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:AerialWires>
      <data:Luminaires>
        <xsl:for-each select="data:AssetReprocessSet/data:Luminaires/data:Luminaire">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Luminaires/data:Luminaire">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Luminaires>
      <data:Vaults>
        <xsl:for-each select="data:AssetReprocessSet/data:Vaults/data:Vault">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Vaults/data:Vault">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Vaults>
      <data:Manholes>
        <xsl:for-each select="data:AssetReprocessSet/data:Manholes/data:Manhole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Manholes/data:Manhole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Manholes>
      <data:Handholes>
        <xsl:for-each select="data:AssetReprocessSet/data:Handholes/data:Handhole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Handholes/data:Handhole">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Handholes>
      <data:AerialSwitches>
        <xsl:for-each select="data:AssetReprocessSet/data:AerialSwitches/data:AerialSwitch">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:AerialSwitches/data:AerialSwitch">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:AerialSwitches>
      <data:Transformers>
        <xsl:for-each select="data:AssetReprocessSet/data:Transformers/data:Transformer">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Transformers/data:Transformer">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Transformers>
      <data:Cabinets>
        <xsl:for-each select="data:AssetReprocessSet/data:Cabinets/data:Cabinet">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Cabinets/data:Cabinet">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Cabinets>
      <data:Conductors>
        <xsl:for-each select="data:AssetReprocessSet/data:Conductors/data:Conductor">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Conductors/data:Conductor">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Conductors>
      <data:Cables>
        <xsl:for-each select="data:AssetReprocessSet/data:Cables/data:Cable">
          <xsl:copy-of select="."/>
        </xsl:for-each>
        <xsl:for-each select="$newAssets/data:AssetReprocessSet/data:Cables/data:Cable">
          <xsl:copy-of select="."/>
        </xsl:for-each>
      </data:Cables>


      </data:AssetReprocessSet>
  </xsl:template>

</xsl:stylesheet>
