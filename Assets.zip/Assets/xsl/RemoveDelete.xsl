<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:ns1="http://schemas.microsoft.com/2003/10/Serialization/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:bpel="http://docs.oasis-open.org/wsbpel/2.0/process/executable" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:wsa10="http://www.w3.org/2005/08/addressing" xmlns:bpm="http://xmlns.oracle.com/bpmn20/extensions" xmlns:soap12="http://schemas.xmlsoap.org/wsdl/soap12/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:mime="http://schemas.xmlsoap.org/wsdl/mime/" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:wsx="http://schemas.xmlsoap.org/ws/2004/09/mex" xmlns:socket="http://www.oracle.com/XSL/Transform/java/oracle.tip.adapter.socket.ProtocolTranslator" xmlns:wsap="http://schemas.xmlsoap.org/ws/2004/08/addressing/policy" xmlns:wsaw="http://www.w3.org/2006/05/addressing/wsdl" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:common="urn:epcor:as:Common" xmlns:mhdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.mediator.service.common.functions.MediatorExtnFunction" xmlns:tns="urn:epcor:as:ivara:ws:AssetService:Mediator" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype" xmlns:med="http://schemas.oracle.com/mediator/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy" xmlns:xdk="http://schemas.oracle.com/bpel/extension/xpath/function/xdk" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:msc="http://schemas.microsoft.com/ws/2005/12/wsdl/contract" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:bpmn="http://schemas.oracle.com/bpm/xpath" xmlns:wsam="http://www.w3.org/2007/05/addressing/metadata" xmlns:ldap="http://schemas.oracle.com/xpath/extension/ldap" exclude-result-prefixes="xsi xsl soap12 soap mime data types tns plnk xsd wsa ns1 wsa10 ns2 soapenc wsdl wsx wsap wsaw wsp msc wsu wsam xp20 bpws bpel bpm ora socket mhdr oraext dvm hwf med ids xdk xref bpmn ldap common">

  <xsl:template match="/data:Poles">
    <data:Poles>
      <xsl:for-each select="data:Pole[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Poles>
  </xsl:template>

  <xsl:template match="/data:TransPoles">
    <data:TransPoles>
      <xsl:for-each select="data:TransPole[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:TransPoles>
  </xsl:template>

    <xsl:template match="/data:TransStructures">
    <data:TransStructures>
      <xsl:for-each select="data:TransStructure[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:TransStructures>
  </xsl:template>


  <xsl:template match="/data:Pads">
    <data:Pads>
      <xsl:for-each select="data:Pad[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Pads>
  </xsl:template>

  <xsl:template match="/data:Pedestals">
    <data:Pedestals>
      <xsl:for-each select="data:Pedestal[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Pedestals>
  </xsl:template>

  <xsl:template match="/data:DecorativePoles">
    <data:DecorativePoles>
      <xsl:for-each select="data:DecorativePole[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:DecorativePoles>
  </xsl:template>

  <xsl:template match="/data:AerialWires">
    <data:AerialWires>
      <xsl:for-each select="data:AerialWire[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:AerialWires>
  </xsl:template>

  <xsl:template match="/data:Luminaires">
    <data:Luminaires>
      <xsl:for-each select="data:Luminaire[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Luminaires>
  </xsl:template>

  <xsl:template match="/data:Vaults">
    <data:Vaults>
      <xsl:for-each select="data:Vault[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Vaults>
  </xsl:template>

  <xsl:template match="/data:Manholes">
    <data:Manholes>
      <xsl:for-each select="data:Manhole[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Manholes>
  </xsl:template>

  <xsl:template match="/data:Handholes">
    <data:Handholes>
      <xsl:for-each select="data:Handhole[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Handholes>
  </xsl:template>

  <xsl:template match="/data:AerialSwitches">
    <data:AerialSwitches>
      <xsl:for-each select="data:AerialSwitch[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:AerialSwitches>
  </xsl:template>

  <xsl:template match="/data:Transformers">
    <data:Transformers>
      <xsl:for-each select="data:Transformer[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Transformers>
  </xsl:template>

  <xsl:template match="/data:Cabinets">
    <data:Cabinets>
      <xsl:for-each select="data:Cabinet[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Cabinets>
  </xsl:template>

    <xsl:template match="/data:Conductors">
    <data:Conductors>
      <xsl:for-each select="data:Conductor[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Conductors>
  </xsl:template>
  
  <xsl:template match="/data:Cables">
    <data:Cables>
      <xsl:for-each select="data:Cable[not(data:SourceType='delete')]">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:Cables>
  </xsl:template>
  
  
</xsl:stylesheet>
