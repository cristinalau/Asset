<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:ns1="http://schemas.microsoft.com/2003/10/Serialization/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:bpel="http://docs.oasis-open.org/wsbpel/2.0/process/executable" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:wsa10="http://www.w3.org/2005/08/addressing" xmlns:bpm="http://xmlns.oracle.com/bpmn20/extensions" xmlns:soap12="http://schemas.xmlsoap.org/wsdl/soap12/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:mime="http://schemas.xmlsoap.org/wsdl/mime/" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:wsx="http://schemas.xmlsoap.org/ws/2004/09/mex" xmlns:socket="http://www.oracle.com/XSL/Transform/java/oracle.tip.adapter.socket.ProtocolTranslator" xmlns:wsap="http://schemas.xmlsoap.org/ws/2004/08/addressing/policy" xmlns:wsaw="http://www.w3.org/2006/05/addressing/wsdl" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:common="urn:epcor:as:Common" xmlns:mhdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.mediator.service.common.functions.MediatorExtnFunction" xmlns:tns="urn:epcor:as:ivara:ws:AssetService:Mediator" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype" xmlns:med="http://schemas.oracle.com/mediator/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy" xmlns:xdk="http://schemas.oracle.com/bpel/extension/xpath/function/xdk" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:msc="http://schemas.microsoft.com/ws/2005/12/wsdl/contract" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:bpmn="http://schemas.oracle.com/bpm/xpath" xmlns:wsam="http://www.w3.org/2007/05/addressing/metadata" xmlns:ldap="http://schemas.oracle.com/xpath/extension/ldap" exclude-result-prefixes="xsi xsl soap12 soap mime data types tns plnk xsd wsa ns1 wsa10 ns2 soapenc wsdl wsx wsap wsaw wsp msc wsu wsam xp20 bpws bpel bpm ora socket mhdr oraext dvm hwf med ids xdk xref bpmn ldap common">
                
  <xsl:param name="processControl"/>
  <xsl:param name="environmentControl"/>
  
  <xsl:template match="/data:AssetsNotificationGroup">
      <data:AssetsNotificationGroup>
        <xsl:copy-of select="data:Assignee"/>
        <xsl:copy-of select="data:Assets"/>

        <data:EmailSubject>
            <xsl:value-of select="concat('Ivara Interface ',$processControl/common:processControl/common:interface,'(',$environmentControl/common:environmentControl/common:instanceId,') has warnings.')"/>
         </data:EmailSubject>
        <data:EmailBody>
        &lt;style media="screen" type="text/css">
        
        .epcorHFTable
        {  
        background:#D3E4E5;
        color:#66a3d3;
        border	: 1px solid;	
        border-color: grey;
        border-collapse:collapse;
        font: normal 12px verdana, arial, helvetica, sans-serif;
        }
        
        .epcorHFTable tr td
        {
        color:#363636;
        padding: 3px 5px;
        margin: 3px;
        border	: 1px solid;	
        border-color: grey;
        }    
        
        .epcorHFTable tr th
        {
        padding: 3px 5px;
        margin: 3px;
        background-color: #87B4D9;
        color: black;
        border	: 1px solid;	
        border-color: grey;
        }
        
        &lt;/style>
        Hi, 
        
        &lt;br/>
        &lt;br/>
        
        The following assets were imported succesfully with the following warnings. If you have any concerns, please contact IT support. 
        
        &lt;br/>
        &lt;br/>
        &lt;table class="epcorHFTable">
          &lt;tr>
            &lt;th>Asset Type&lt;/th>
            &lt;th>Asset Number&lt;/th>
            &lt;th>Error Text&lt;/th>
          &lt;/tr>
          
        <xsl:for-each select="data:Assets/data:Asset">
          <xsl:sort select="data:AssetNumber"/>

          <xsl:choose>
            <xsl:when test="position() mod 2 = 1">
              &lt;tr> &lt;td>
              <xsl:value-of select="data:AssetType"/>
              &lt;/td> &lt;td>
              <xsl:value-of select="data:ID"/>
              &lt;/td> &lt;td>
              <xsl:value-of select="data:ErrorText"/>
              &lt;/td> &lt;/tr>
            </xsl:when>
            <xsl:otherwise>
              &lt;tr class="even"> &lt;td>
              <xsl:value-of select="data:AssetType"/>
              &lt;/td> &lt;td>
              <xsl:value-of select="data:ID"/>
              &lt;/td> &lt;td>
              <xsl:value-of select="data:ErrorText"/>
              &lt;/td> &lt;/tr>
            </xsl:otherwise>
          </xsl:choose>

        </xsl:for-each>
        &lt;/table>
        &lt;br/>

        </data:EmailBody>
      </data:AssetsNotificationGroup>
  </xsl:template>


</xsl:stylesheet>