<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:ehdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.esb.server.headers.ESBHeaderFunctions" xmlns:ivws="urn:epcor:as:ivara:schema:AssetService:1" xmlns:common="urn:epcor:as:Common" exclude-result-prefixes="xsl types tns xsd bpws xp20 xref orcl ora hwf ids ehdr ivws dvm common" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
                
  <xsl:param name="assetTrigger"/>
 
  <xsl:template match="/">
    <data:AssetTriggers>
      <xsl:for-each select="data:AssetTriggers/data:AssetTrigger">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$assetTrigger/data:AssetTrigger">
        <xsl:copy-of select="."/>
      </xsl:for-each>
    </data:AssetTriggers>
  </xsl:template>


</xsl:stylesheet>