<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:common="urn:epcor:as:Common" exclude-result-prefixes="xsl types xsd bpws xp20 xref orcl ora hwf ids dvm common" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
   <xsl:param name="assetTrigger"/>
   <xsl:param name="processControl"/>
   <xsl:template match="/">
      <xsl:variable name="time" select="$assetTrigger/data:AssetTrigger/data:CreatedDate"/>
      <xsl:variable name="uuid" select="orcl:generate-guid()"/>
      <xsl:variable name="existed">
         <xsl:choose>
            <xsl:when test="count(data:AssetTriggerSets/data:AssetTriggerSet[$time >= data:StartDate and $time &lt;= data:EndDate]) > 0">true</xsl:when>
            <xsl:otherwise>false</xsl:otherwise>
         </xsl:choose>
      </xsl:variable>
      <data:AssetTriggerSets>
         <xsl:for-each select="data:AssetTriggerSets/data:AssetTriggerSet">
            <xsl:choose>
               <xsl:when test="$time >= data:StartDate and $time &lt;= data:EndDate">
                   <data:between>yes </data:between>
                <data:AssetTriggerSet>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:EndDate"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:UUID"/>
                     <data:AssetTriggers>
                        <xsl:for-each select="data:AssetTriggers/data:AssetTrigger">
                           <xsl:copy-of select="."/>
                        </xsl:for-each>
                        <xsl:copy-of select="$assetTrigger"/>
                     </data:AssetTriggers>
                  </data:AssetTriggerSet>
               </xsl:when>
               <xsl:otherwise>
                  <data:between>no </data:between>
                  <xsl:copy-of select="."/>
               </xsl:otherwise>
            </xsl:choose>
         </xsl:for-each>
         <xsl:if test="string($existed)='false'">
                  <data:exist>no </data:exist>
           <data:AssetTriggerSet>
               <data:StartDate>
                  <xsl:value-of select="xp20:subtract-dayTimeDuration-from-dateTime($time,'PT300S')"/>
               </data:StartDate>
               <data:EndDate>
                  <xsl:value-of select="xp20:add-dayTimeDuration-to-dateTime($time, concat('PT',$processControl/common:processControl/common:duration,'S'))"/>
               </data:EndDate>
               <data:ProcessedDate>
                  <xsl:value-of select="xp20:add-dayTimeDuration-to-dateTime($assetTrigger/data:AssetTrigger/data:ProcessedDate, concat('PT',$processControl/common:processControl/common:duration,'S'))"/>
               </data:ProcessedDate>
               <data:UUID>
                  <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
               </data:UUID>
               <data:AssetTriggers>
                  <xsl:copy-of select="$assetTrigger"/>
               </data:AssetTriggers>
            </data:AssetTriggerSet>
         </xsl:if>
      </data:AssetTriggerSets>
   </xsl:template>
   
   
     
</xsl:stylesheet>