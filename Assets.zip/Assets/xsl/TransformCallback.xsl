<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:ehdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.esb.server.headers.ESBHeaderFunctions" xmlns:ebs="http://xmlns.oracle.com/pcbpel/adapter/db/EBSPoles" xmlns:ivws="urn:epcor:as:ivara:schema:AssetService:1" exclude-result-prefixes="xsl types xsd bpws xp20 xref orcl ora hwf ids ehdr xsi ivws dvm ebs" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">

  <xsl:template match="/data:EPPoleReturns">
    <data:PoleReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:PoleReturns>
  </xsl:template>

    <xsl:template match="/data:EPTransPoleReturns">
    <data:TransPoleReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:TransPoleReturns>
  </xsl:template>
  
 
  <xsl:template match="/data:EPPadReturns">
    <data:PadReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:PadReturns>
  </xsl:template>

  <xsl:template match="/data:EPPedestalReturns">
    <data:PedestalReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:PedestalReturns>
  </xsl:template>

  <xsl:template match="/data:EPDecorativePoleReturns">
    <data:DecorativePoleReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:DecorativePoleReturns>
  </xsl:template>

  <xsl:template match="/data:EPAerialWireReturns">
    <data:AerialWireReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:AerialWireReturns>
  </xsl:template>

  <xsl:template match="/data:EPLuminaireReturns">
    <data:LuminaireReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:LuminaireReturns>
  </xsl:template>

  <xsl:template match="/data:EPVaultReturns">
    <data:VaultReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:VaultReturns>
  </xsl:template>

  <xsl:template match="/data:EPManholeReturns">
    <data:ManholeReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:ManholeReturns>
  </xsl:template>

  <xsl:template match="/data:EPHandholeReturns">
    <data:HandholeReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:HandholeReturns>
  </xsl:template>

  <xsl:template match="/data:EPAerialSwitchReturns">
    <data:AerialSwitchReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:AerialSwitchReturns>
  </xsl:template>

  <xsl:template match="/data:EPTransformerReturns">
    <data:TransformerReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:TransformerReturns>
  </xsl:template>

  <xsl:template match="/data:EPCabinetReturns">
    <data:CabinetReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:CabinetReturns>
  </xsl:template>
 
   <xsl:template match="/data:EPConductorReturns">
    <data:ConductorReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:ConductorReturns>
  </xsl:template>

    <xsl:template match="/data:EPCableReturns">
    <data:CableReturns>
      <xsl:apply-templates select="data:EPReturn"/>
      <data:Session>
        <xsl:value-of select="data:Session"/>
      </data:Session>
    </data:CableReturns>
  </xsl:template>
 


 
  <xsl:template match="data:EPReturn">
    <data:Return>
      <data:UUID>
        <xsl:value-of select="data:EPUUID"/>
      </data:UUID>
      <data:CreatedDate>
        <xsl:value-of select="data:EPCreatedDate"/>
      </data:CreatedDate>
      <data:Site>
        <xsl:choose>
            <xsl:when test="boolean(string(data:EPSite))">
                <xsl:value-of select="data:EPSite"/>
            </xsl:when>
            <xsl:otherwise>Global Site</xsl:otherwise>
        </xsl:choose>
      </data:Site>
      <data:IvaraOI>
        <xsl:value-of select="data:EPIvaraOI"/>
      </data:IvaraOI>
      <data:ErrorCode>
        <xsl:value-of select="data:EPErrorCode"/>
      </data:ErrorCode>
      <data:ErrorText>
        <xsl:value-of select="data:EPErrorText"/>
      </data:ErrorText>
    </data:Return>
  </xsl:template>
</xsl:stylesheet>
