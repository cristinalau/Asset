<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:ehdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.esb.server.headers.ESBHeaderFunctions" xmlns:common="urn:epcor:as:Common" exclude-result-prefixes="xsl types tns xsd bpws xp20 xref orcl ora hwf ids ehdr ivws dvm common" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">

  <xsl:param name="reprocessControl"/>

  <xsl:template match="/data:AssetsNotificationGroup">
    <data:AssetsNotificationGroup>
      <xsl:copy-of select="data:Assignee"/>
      <xsl:copy-of select="data:EmailBody"/>
      <xsl:copy-of select="data:EmailSubject"/>
      <data:Assets>
        <xsl:apply-templates select="data:Assets/data:Asset"/>
      </data:Assets>
    </data:AssetsNotificationGroup>
  </xsl:template>
  
  <xsl:template match="data:Asset">
    <data:Asset>
     <xsl:copy-of select="data:UUID"/>
     <xsl:copy-of select="data:ID"/>
     <xsl:copy-of select="data:AssetType"/>
     <xsl:copy-of select="data:OwnerType"/>
     <xsl:copy-of select="data:OwnerName"/>
     <xsl:copy-of select="data:GeoLocation"/>
     <xsl:copy-of select="data:StartDate"/>
     <xsl:copy-of select="data:Circuits"/>
     <xsl:copy-of select="data:SourceStatus"/>
     <xsl:copy-of select="data:SourceType"/>
     <xsl:copy-of select="data:PreviousAsset"/>
     <xsl:copy-of select="data:ProcessedDate"/>
     <xsl:copy-of select="data:ErrorCode"/>
     <xsl:copy-of select="data:ErrorText"/>
      <data:Action>
        <xsl:value-of select="$reprocessControl/common:reprocessControl/common:action"/>
      </data:Action>
      <xsl:copy-of select="data:Site"/>
    </data:Asset>
  </xsl:template>
  
</xsl:stylesheet>