<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:common="urn:epcor:as:Common" exclude-result-prefixes="xsl types xsd bpws xp20 xref orcl ora hwf ids dvm common" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
                
  <xsl:param name="assetTriggerCompletion"/>
 
  <xsl:template match="/data:AssetTriggerSet">
    <xsl:variable name="uuid" select="$assetTriggerCompletion/data:AssetTriggerCompletion/data:AssetTrigger/data:UUID"/>
    
    <data:AssetTriggerSet>
      <xsl:copy-of select="data:StartDate"/>
      <xsl:copy-of select="data:EndDate"/>
      
      <data:AssetTriggers>
        <xsl:for-each select="data:AssetTriggers/data:AssetTrigger">
          <xsl:choose>
            <xsl:when test="data:UUID=$uuid">
              <data:AssetTrigger>
                <xsl:copy-of select="data:Name"/>
                <xsl:copy-of select="data:UUID"/>
                <data:Active>false</data:Active>
                <xsl:copy-of select="data:FileName"/>
                <xsl:copy-of select="data:AssetLoads"/>
                <xsl:copy-of select="data:CreatedDate"/>
              </data:AssetTrigger>
            </xsl:when>
            <xsl:otherwise>
              <xsl:copy-of select="."/>
            </xsl:otherwise>
          </xsl:choose>
        </xsl:for-each>
      </data:AssetTriggers>
    </data:AssetTriggerSet>
  </xsl:template>

</xsl:stylesheet>