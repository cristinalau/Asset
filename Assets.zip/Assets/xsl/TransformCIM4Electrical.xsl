<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0"
                xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20"
                xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/"
                xmlns:cim="http://iec.ch/TC57/2007/profile"
                xmlns:bpel="http://docs.oasis-open.org/wsbpel/2.0/process/executable"
                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:pc="http://xmlns.oracle.com/pcbpel/"
                xmlns:bpm="http://xmlns.oracle.com/bpmn20/extensions"
                xmlns:plt="http://schemas.xmlsoap.org/ws/2003/05/partner-link/"
                xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:ora="http://schemas.oracle.com/xpath/extension"
                xmlns:socket="http://www.oracle.com/XSL/Transform/java/oracle.tip.adapter.socket.ProtocolTranslator"
                xmlns:data="urn:epcor:as:ivara:ws:Data"
                xmlns:mhdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.mediator.service.common.functions.MediatorExtnFunction"
                xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc"
                xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue"
                xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath"
                xmlns:jca="http://xmlns.oracle.com/pcbpel/wsdl/jca/"
                xmlns:med="http://schemas.oracle.com/mediator/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath"
                xmlns:xdk="http://schemas.oracle.com/bpel/extension/xpath/function/xdk"
                xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:bpmn="http://schemas.oracle.com/bpm/xpath"
                xmlns:ldap="http://schemas.oracle.com/xpath/extension/ldap"
                exclude-result-prefixes="xsi xsl imp1 pc plt wsdl jca xsd ns1 data ns0 xp20 bpws bpel bpm ora socket mhdr oraext dvm hwf med ids xdk xref bpmn ldap">

    <xsl:variable name="year" select="xp20:year-from-dateTime(xp20:current-date())"/>

    <xsl:template match="/cim:EpcTransformers">
        <data:Transformers>
            <xsl:apply-templates select="cim:EpcTransformer"/>
        </data:Transformers>
    </xsl:template>

    <xsl:template match="/cim:EpcCabinets">
        <data:Cabinets>
            <xsl:apply-templates select="cim:EpcCabinet"/>
        </data:Cabinets>
    </xsl:template>

    <xsl:template match="/cim:EpcAerialSwitches">
        <data:AerialSwitches>
            <xsl:apply-templates select="cim:EpcAerialSwitch"/>
        </data:AerialSwitches>
    </xsl:template>

    <xsl:template match="cim:EpcTransformer">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:Transformer>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <xsl:if test="count(cim:EO_mRID) > 0">
                <data:EOID>
                    <xsl:value-of select="cim:EO_mRID" />
                </data:EOID>
            </xsl:if>
            <data:Name>
                <xsl:value-of select="cim:name"/>
            </data:Name>
            <data:Description>
                <xsl:value-of select="cim:description"/>
            </data:Description>
            <data:AssetType>Transformer</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <data:Category>
                <xsl:choose>
                    <xsl:when test="(xp20:matches(cim:type,'^(D|C|FS|H|HN|HNX|K|N|P|S|W|Y|Z|Aerial – Single Phase|TJ|TK|TL|TM|TY|TR|TQ|TKN|TN|TX|TW|TZ|Aerial – Three Phase)$') and cim:category='UG') or cim:type='Aerial Multi Step (bi-directional)'">Aerial</xsl:when>
                    <xsl:otherwise>
                    <xsl:choose>
                        <xsl:when test="cim:type='UG Multi Step (bi-directional)'">UG</xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="cim:category"/>
                        </xsl:otherwise>
                    </xsl:choose>
                    </xsl:otherwise>
                </xsl:choose>
            </data:Category>
            <data:BankConfiguration>
                <xsl:value-of select="cim:bankConfiguration"/>
            </data:BankConfiguration>
            <data:ServiceIPPIndicator>
                <xsl:value-of select="cim:serviceIPPIndicator"/>
            </data:ServiceIPPIndicator>
            <data:SpecialLoading>
                <xsl:value-of select="cim:specialLoading"/>
            </data:SpecialLoading>
            <data:TransformerType>
                <xsl:value-of select="cim:type"/>
            </data:TransformerType>
            <data:DemandPoints>
                <xsl:value-of select="cim:totalServiceDeliveryPoint"/>
            </data:DemandPoints>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:if test="count(cim:poleNumber) >0">
                <data:Poles>
                    <data:Pole>
                        <data:ID>
                            <xsl:value-of select="cim:poleNumber"/>
                        </data:ID>
                    </data:Pole>
                </data:Poles>
            </xsl:if>
            <xsl:if test="count(cim:departmentNumber) >0">
                <data:Pads>
                    <data:Pad>
                        <data:ID>
                            <xsl:value-of select="cim:departmentNumber"/>
                        </data:ID>
                    </data:Pad>
                </data:Pads>
            </xsl:if>
            <xsl:if test="count(cim:vaultNumber) >0">
                <data:Vaults>
                    <data:Vault>
                        <data:ID>
                            <xsl:value-of select="cim:vaultNumber"/>
                        </data:ID>
                    </data:Vault>
                </data:Vaults>
            </xsl:if>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
        </data:Transformer>
    </xsl:template>

    <xsl:template match="cim:EpcCabinet">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:Cabinet>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <xsl:if test="count(cim:EO_mRID) > 0">
                <data:EOID>
                    <xsl:value-of select="cim:EO_mRID" />
                </data:EOID>
            </xsl:if>
            <data:AssetType>Cabinet</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <data:LiveFrontIndicator>
                <xsl:value-of select="cim:isLiveFront"/>
            </data:LiveFrontIndicator>
            <data:CabinetType>
                <xsl:value-of select="cim:type"/>
            </data:CabinetType>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <xsl:if test="count(cim:padDepartmentNumber) >0">
                <data:Pads>
                    <data:Pad>
                        <data:ID>
                            <xsl:value-of select="cim:padDepartmentNumber"/>
                        </data:ID>
                    </data:Pad>
                </data:Pads>
            </xsl:if>
            <xsl:if test="count(cim:pedDepartmentNumber) >0">
                <data:Pedestals>
                    <data:Pedestal>
                        <data:ID>
                            <xsl:value-of select="cim:pedDepartmentNumber"/>
                        </data:ID>
                    </data:Pedestal>
                </data:Pedestals>
            </xsl:if>
            <xsl:if test="count(cim:relatedVaults/cim:EpcVault) >0">
                <data:Vaults>
                    <xsl:for-each select="cim:relatedVaults/cim:EpcVault">
                        <data:Vault>
                            <data:ID>
                                <xsl:value-of select="cim:mRID" />
                            </data:ID>
                            <xsl:if test="count(cim:EO_mRID) > 0">
                                <data:EOID>
                                    <xsl:value-of select="cim:EO_mRID" />
                                </data:EOID>
                            </xsl:if>
                        </data:Vault>
                    </xsl:for-each>
                </data:Vaults>
            </xsl:if>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
              </data:Cabinet>
    </xsl:template>

    <xsl:template match="cim:EpcAerialSwitch">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:AerialSwitch>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <xsl:if test="count(cim:EO_mRID) > 0">
                <data:EOID>
                    <xsl:value-of select="cim:EO_mRID" />
                </data:EOID>
            </xsl:if>
            <data:Name>
                <xsl:value-of select="cim:name"/>
            </data:Name>
            <data:Description>
                <xsl:value-of select="cim:description"/>
            </data:Description>
            <data:AssetType>AerialSwitch</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <xsl:choose>
                <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="cim:startDate"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
            </xsl:choose>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                <data:PreviousAsset>
                    <data:ID>
                        <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                    </data:ID>
                    <xsl:if test="count(cim:EpcAssetHistory/cim:EO_mRID) > 0">
                        <data:EOID>
                            <xsl:value-of select="cim:EpcAssetHistory/cim:EO_mRID" />
                        </data:EOID>
                    </xsl:if>
                </data:PreviousAsset>
            </xsl:if>
            <data:AerialSwitchType>
                <xsl:value-of select="cim:type"/>
            </data:AerialSwitchType>
            <data:Phasing>
                <xsl:value-of select="cim:phasing"/>
            </data:Phasing>
            <data:NormalStatus>
                <xsl:value-of select="cim:normalStatus"/>
            </data:NormalStatus>
            <data:Mounting>
                <xsl:value-of select="cim:mounting"/>
            </data:Mounting>
            <data:VoltageRating>
                <xsl:value-of select="cim:voltageRating"/>
            </data:VoltageRating>
            <data:ContinuousAmpRating>
                <xsl:value-of select="cim:continuousAmpRating"/>
            </data:ContinuousAmpRating>
            <data:FuseUnits>
                <xsl:value-of select="cim:fuseUnits"/>
            </data:FuseUnits>
            <data:SwitchUnits>
                <xsl:value-of select="cim:switchUnits"/>
            </data:SwitchUnits>
            <data:SwitchSize>
                <xsl:value-of select="cim:size"/>
            </data:SwitchSize>
            <data:LoadBreak>
                <xsl:value-of select="cim:loadBreak"/>
            </data:LoadBreak>
            <data:VendorName>
                <xsl:value-of select="cim:manufacturer"/>
            </data:VendorName>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:if test="count(cim:poleNumber) >0">
                <data:Poles>
                    <data:Pole>
                        <data:ID>
                            <xsl:value-of select="cim:poleNumber"/>
                        </data:ID>
                    </data:Pole>
                </data:Poles>
            </xsl:if>
            <data:CircuitTieIndicator>
                <xsl:value-of select="cim:circuitTieIndicator"/>
            </data:CircuitTieIndicator>
            <data:Grouping>
                <xsl:value-of select="cim:grouping"/>
            </data:Grouping>
            <xsl:if test="count(cim:relatedCables/cim:EpcCable) >0">
                <data:Cables>
                    <xsl:for-each select="cim:relatedCables/cim:EpcCable">
                        <data:Cable>
                            <data:ID>
                                <xsl:value-of select="cim:mRID" />
                            </data:ID>
                            <xsl:if test="count(cim:EO_mRID) > 0">
                                <data:EOID>
                                    <xsl:value-of select="cim:EO_mRID" />
                                </data:EOID>
                            </xsl:if>
                        </data:Cable>
                    </xsl:for-each>
                </data:Cables>
            </xsl:if>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
        </data:AerialSwitch>
    </xsl:template>

    <xsl:template match="cim:EpcCable">
        <!--xsl:if test="cim:ownerType!='Customer'"-->
            <xsl:variable name="uuid" select="oraext:generate-guid()"/>
            <data:Cable>
                <data:UUID>
                    <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
                </data:UUID>
                <data:ID>
                    <xsl:value-of select="cim:mRID"/>
                </data:ID>
                <xsl:if test="count(cim:EO_mRID) > 0">
                    <data:EOID>
                        <xsl:value-of select="cim:EO_mRID" />
                    </data:EOID>
                </xsl:if>
                <data:Name>
                    <xsl:value-of select="cim:name"/>
                </data:Name>
                <data:Description>
                    <xsl:value-of select="cim:description"/>
                </data:Description>
                <data:Title>
                    <xsl:value-of select="cim:description"/>
                </data:Title>
                <data:AssetType>Cable</data:AssetType>
                <data:OwnerType>
				
				<data:Material>
                    <xsl:value-of select="cim:material"/>
                </data:Material>
                 <data:Class>
                    <xsl:value-of select="cim:class"/>
                </data:Class>
                <data:Usage>
                    <xsl:value-of select="cim:usage"/>
                </data:Usage>
                <data:Phases>
                    <xsl:value-of select="cim:phasing"/>
                </data:Phases>
                    <xsl:value-of select="cim:ownerType"/>
                </data:OwnerType>
                <data:OwnerName>
                    <xsl:value-of select="cim:ownerName"/>
                </data:OwnerName>
                <data:GeoLocation>
                    <data:Description>
                        <xsl:value-of select="cim:EpcLocation/cim:description"/>
                    </data:Description>
                    <data:X>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                    </data:X>
                    <data:Y>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                    </data:Y>
                    <data:Cadastral>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                    </data:Cadastral>
                    <data:Neighbourhood>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                    </data:Neighbourhood>
                    <data:NearestIntersection>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                    </data:NearestIntersection>
                </data:GeoLocation>
				  <data:StartDate>
                            <xsl:value-of select="cim:startDate"/>
                  </data:StartDate>
                <xsl:if test="count(cim:Circuit) >0">
                    <data:Circuits>
                        <xsl:apply-templates select="cim:Circuit"/>
                    </data:Circuits>
                </xsl:if>
                <data:SourceStatus>
                    <xsl:choose>
                        <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="cim:Status/cim:value"/>
                        </xsl:otherwise>
                    </xsl:choose>
                </data:SourceStatus>
                <data:SourceType>
                    <xsl:choose>
                        <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="cim:epcSubCategory"/>
                        </xsl:otherwise>
                    </xsl:choose>
                </data:SourceType>
                <data:Grouping>
                    <xsl:value-of select="cim:ownerType"/>
                </data:Grouping>

                <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                    <data:PreviousAsset>
                        <data:ID>
                            <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                        </data:ID>
                        <xsl:if test="count(cim:EpcAssetHistory/cim:EO_mRID) > 0">
                            <data:EOID>
                                <xsl:value-of select="cim:EpcAssetHistory/cim:EO_mRID" />
                            </data:EOID>
                        </xsl:if>
                    </data:PreviousAsset>
                </xsl:if>
                <data:WorkOrderNumber>
                    <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
                </data:WorkOrderNumber>


				<data:Phasing>
                    <xsl:value-of select="cim:phasing"/>
                </data:Phasing>
				<data:Insulation>             		<xsl:value-of select="cim:insulation"/>						</data:Insulation>
				<data:Arrangement>					<xsl:value-of select="cim:arrangement"/>						</data:Arrangement>
				<data:CalculatedLength>					<xsl:value-of select="cim:calculatedLength"/>						</data:CalculatedLength>
				<data:EpcInjectable>					<xsl:value-of select="cim:epcInjectable"/>						</data:EpcInjectable>
				<data:EpcInjectedDate>					<xsl:value-of select="cim:epcInjectedDate"/>						</data:EpcInjectedDate>
				<data:EpcInjectionMethod>					<xsl:value-of select="cim:epcInjectionMethod"/>						</data:EpcInjectionMethod>
				<data:NeutralConfiguration>					<xsl:value-of select="cim:neutralConfiguration"/>						</data:NeutralConfiguration>
				<data:NominalVoltage>					<xsl:value-of select="cim:nominalVoltage"/>						</data:NominalVoltage>
				<data:OutsideDiameter>					<xsl:value-of select="cim:outsiDediameter"/>						</data:OutsideDiameter>
				<data:RatedVoltage>					<xsl:value-of select="cim:ratedVoltage"/>						</data:RatedVoltage>
				<data:RepairSplices>					<xsl:value-of select="cim:repairSplices"/>						</data:RepairSplices>
				<data:Size>					<xsl:value-of select="cim:size"/>						</data:Size>
				<data:Splices>					<xsl:value-of select="cim:splices"/>						</data:Splices>
				<data:AvailableDucts>					<xsl:value-of select="cim:availableDucts"/>						</data:AvailableDucts>
				<data:UsedDucts>					<xsl:value-of select="cim:usedDucts"/>						</data:UsedDucts>
				<data:CollapsedDucts>					<xsl:value-of select="cim:collapsedDucts"/>						</data:CollapsedDucts>
				<data:AbandonedDucts>					<xsl:value-of select="cim:abandonedDucts"/>						</data:AbandonedDucts>
				<data:OtherDucts>					<xsl:value-of select="cim:otherDucts"/>						</data:OtherDucts>
				<data:DuctMaterial>					<xsl:value-of select="cim:ductMaterial"/>						</data:DuctMaterial>
				<data:ProtectiveDevice>					<xsl:value-of select="cim:protectiveDevice"/>						</data:ProtectiveDevice>



                <xsl:if test="count(cim:relatedPads/cim:EpcPad) >0">
                    <data:Pads>
                        <xsl:for-each select="cim:relatedPads/cim:EpcPad">
                            <data:Pad>
                                <data:ID>
                                    <xsl:value-of select="cim:mRID" />
                                </data:ID>
                                <xsl:if test="count(cim:EO_mRID) > 0">
                                    <data:EOID>
                                        <xsl:value-of select="cim:EO_mRID" />
                                    </data:EOID>
                                </xsl:if>
                            </data:Pad>
                        </xsl:for-each>
                    </data:Pads>
                </xsl:if>
             <xsl:if test="count(cim:relatedPedestals/cim:EpcPedestal) >0">
                    <data:Pedestals>
                        <xsl:apply-templates select="cim:relatedPedestals/cim:EpcPedestal"/>
                    </data:Pedestals>
                </xsl:if>
                <xsl:if test="count(cim:relatedDecorativePoles/cim:EpcDecorativePole) >0">
                    <data:DecorativePoles>
                        <xsl:for-each select="cim:relatedDecorativePoles/cim:EpcDecorativePole">
                            <data:EpcDecorativePole>
                                <data:ID>
                                    <xsl:value-of select="cim:mRID"/>
                                </data:ID>
                                <xsl:if test="count(cim:EO_mRID) > 0">
                                    <data:EOID>
                                        <xsl:value-of select="cim:EO_mRID" />
                                    </data:EOID>
                                </xsl:if>
                            </data:EpcDecorativePole>
                        </xsl:for-each>
                    </data:DecorativePoles>
                </xsl:if>
                <xsl:if test="count(cim:relatedLuminaires/cim:EpcLuminaire) >0">
                    <data:Luminaires>
                        <xsl:for-each select="cim:relatedLuminaires/cim:EpcLuminaire">
                            <data:EpcLuminaire>
                                <data:ID>
                                    <xsl:value-of select="cim:mRID"/>
                                </data:ID>
                                <xsl:if test="count(cim:EO_mRID) > 0">
                                    <data:EOID>
                                        <xsl:value-of select="cim:EO_mRID" />
                                    </data:EOID>
                                </xsl:if>
                            </data:EpcLuminaire>
                        </xsl:for-each>
                    </data:Luminaires>
                </xsl:if>
                <xsl:if test="count(cim:relatedVaults/cim:EpcVault) >0">
                    <data:Vaults>
                        <xsl:for-each select="cim:relatedVaults/cim:EpcVault">
                            <data:Vault>
                                <data:ID>
                                    <xsl:value-of select="cim:mRID" />
                                </data:ID>
                                <xsl:if test="count(cim:EO_mRID) > 0">
                                    <data:EOID>
                                        <xsl:value-of select="cim:EO_mRID" />
                                    </data:EOID>
                                </xsl:if>
                            </data:Vault>
                        </xsl:for-each>
                    </data:Vaults>
                </xsl:if>
                <xsl:if test="count(cim:relatedSwitches/cim:EpcSwitch) >0">
                    <data:AerialSwitches>
                        <xsl:for-each select="cim:relatedSwitches/cim:EpcSwitch">
                            <data:AerialSwitch>
                                <data:ID>
                                    <xsl:value-of select="cim:mRID" />
                                </data:ID>
                                <xsl:if test="count(cim:EO_mRID) > 0">
                                    <data:EOID>
                                        <xsl:value-of select="cim:EO_mRID" />
                                    </data:EOID>
                                </xsl:if>
                            </data:AerialSwitch>
                        </xsl:for-each>
                    </data:AerialSwitches>
                </xsl:if>
                <xsl:if test="count(cim:relatedFuses/cim:EpcFuse) >0">
                    <data:AerialSwitches>
                        <xsl:for-each select="cim:relatedFuses/cim:EpcFuse">
                            <data:AerialSwitch>
                                <data:ID>
                                    <xsl:value-of select="cim:mRID" />
                                </data:ID>
                                <xsl:if test="count(cim:EO_mRID) > 0">
                                    <data:EOID>
                                        <xsl:value-of select="cim:EO_mRID" />
                                    </data:EOID>
                                </xsl:if>
                            </data:AerialSwitch>
                        </xsl:for-each>
                    </data:AerialSwitches>
                </xsl:if>
                <xsl:if test="count(cim:relatedManholes/cim:EpcManhole) >0">
                    <data:Manholes>
                        <xsl:for-each select="cim:relatedManholes/cim:EpcManhole">
                            <data:Manhole>
                                <data:ID>
                                    <xsl:value-of select="cim:mRID" />
                                </data:ID>
                                <xsl:if test="count(cim:EO_mRID) > 0">
                                    <data:EOID>
                                        <xsl:value-of select="cim:EO_mRID" />
                                    </data:EOID>
                                </xsl:if>
                            </data:Manhole>
                        </xsl:for-each>
                    </data:Manholes>
                </xsl:if>
                <xsl:if test="count(cim:relatedHandholes/cim:EpcHandhole) >0">
                    <data:Handholes>
                        <xsl:for-each select="cim:relatedHandholes/cim:EpcHandhole">
                            <data:Handhole>
                                <data:ID>
                                    <xsl:value-of select="cim:mRID" />
                                </data:ID>
                                <xsl:if test="count(cim:EO_mRID) > 0">
                                    <data:EOID>
                                        <xsl:value-of select="cim:EO_mRID" />
                                    </data:EOID>
                                </xsl:if>
                            </data:Handhole>
                        </xsl:for-each>
                    </data:Handholes>
                </xsl:if>
                <xsl:if test="count(cim:relatedConductors/cim:EpcConductor) >0">
                    <data:Conductors>
                        <xsl:for-each select="cim:relatedConductors/cim:EpcConductor">
                            <data:Conductor>
                                <data:ID>
                                    <xsl:value-of select="cim:mRID" />
                                </data:ID>
                                <xsl:if test="count(cim:EO_mRID) > 0">
                                    <data:EOID>
                                        <xsl:value-of select="cim:EO_mRID" />
                                    </data:EOID>
                                </xsl:if>
                            </data:Conductor>
                        </xsl:for-each>
                    </data:Conductors>
                </xsl:if>
                <xsl:if test="count(cim:multiFamily) > 0">
                    <data:MultiFamily>
                        <xsl:value-of select="cim:multiFamily" />
                    </data:MultiFamily>
                </xsl:if>
            </data:Cable>
        <!--/xsl:if-->
    </xsl:template>

    <xsl:template match="cim:EpcConductor">
        <!--xsl:if test="cim:ownerType!='Customer'"-->
            <xsl:variable name="uuid" select="oraext:generate-guid()"/>
            <data:Conductor>
                <data:UUID>
                    <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
                </data:UUID>
                <data:ID>
                    <xsl:value-of select="cim:mRID"/>
                </data:ID>
                <xsl:if test="count(cim:EO_mRID) > 0">
                    <data:EOID>
                        <xsl:value-of select="cim:EO_mRID" />
                    </data:EOID>
                </xsl:if>
                <data:Name>
                    <xsl:value-of select="cim:name"/>
                </data:Name>
                <data:Description>
                    <xsl:value-of select="cim:description"/>
                </data:Description>
                <data:Title>
                    <xsl:value-of select="cim:description"/>
                </data:Title>
                <data:AssetType>Conductor</data:AssetType>
                <data:OwnerType>
                    <xsl:value-of select="cim:ownerType"/>
                </data:OwnerType>
                <data:OwnerName>
                    <xsl:value-of select="cim:ownerName"/>
                </data:OwnerName>
                <data:GeoLocation>
                    <data:Description>
                        <xsl:value-of select="cim:EpcLocation/cim:description"/>
                    </data:Description>
                    <data:X>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                    </data:X>
                    <data:Y>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                    </data:Y>
                    <data:Cadastral>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                    </data:Cadastral>
                    <data:Neighbourhood>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                    </data:Neighbourhood>
                    <data:NearestIntersection>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                    </data:NearestIntersection>
                </data:GeoLocation>
 					<xsl:choose>
						 <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
							<data:StartDate>
								<xsl:value-of select="cim:startDate"/>
							</data:StartDate>
						</xsl:when>
						<xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
							<data:StartDate>
								<xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
							</data:StartDate>
						</xsl:when>
						<xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
							<data:StartDate>
								<xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
							</data:StartDate>
						</xsl:when>
					</xsl:choose>
				  <xsl:if test="count(cim:Circuit) >0">
                    <data:Circuits>
                        <xsl:apply-templates select="cim:Circuit"/>
                    </data:Circuits>
                </xsl:if>
                <data:SourceStatus>
                    <xsl:choose>
                        <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="cim:Status/cim:value"/>
                        </xsl:otherwise>
                    </xsl:choose>
                </data:SourceStatus>
                <data:SourceType>
                    <xsl:choose>
                        <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="cim:epcSubCategory"/>
                        </xsl:otherwise>
                    </xsl:choose>
                </data:SourceType>
                <data:Grouping>
                    <xsl:value-of select="cim:ownerType"/>
                </data:Grouping>

                <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                    <data:PreviousAsset>
                        <data:ID>
                            <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                        </data:ID>
                        <xsl:if test="count(cim:EpcAssetHistory/cim:EO_mRID) > 0">
                            <data:EOID>
                                <xsl:value-of select="cim:EpcAssetHistory/cim:EO_mRID" />
                            </data:EOID>
                        </xsl:if>
                    </data:PreviousAsset>
                </xsl:if>
                <data:WorkOrderNumber>
                    <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
                </data:WorkOrderNumber>


				<data:Phasing>
                    <xsl:value-of select="cim:phasing"/>
                </data:Phasing>
				<data:Insulation>             		<xsl:value-of select="cim:insulation"/>						</data:Insulation>
				<data:Arrangement>					<xsl:value-of select="cim:arrangement"/>						</data:Arrangement>
				<data:CalculatedLength>					<xsl:value-of select="cim:calculatedLength"/>						</data:CalculatedLength>
				<data:EpcInjectable>					<xsl:value-of select="cim:epcInjectable"/>						</data:EpcInjectable>
				<data:EpcInjectedDate>					<xsl:value-of select="cim:epcInjectedDate"/>						</data:EpcInjectedDate>
				<data:EpcInjectionMethod>					<xsl:value-of select="cim:epcInjectionMethod"/>						</data:EpcInjectionMethod>
				<data:NeutralConfiguration>					<xsl:value-of select="cim:neutralConfiguration"/>						</data:NeutralConfiguration>
				<data:NominalVoltage>					<xsl:value-of select="cim:nominalVoltage"/>						</data:NominalVoltage>
				<data:OutsideDiameter>					<xsl:value-of select="cim:outsiDediameter"/>						</data:OutsideDiameter>
				<data:RatedVoltage>					<xsl:value-of select="cim:ratedVoltage"/>						</data:RatedVoltage>
				<data:RepairSplices>					<xsl:value-of select="cim:repairSplices"/>						</data:RepairSplices>
				<data:Size>					<xsl:value-of select="cim:size"/>						</data:Size>
				<data:Splices>					<xsl:value-of select="cim:splices"/>						</data:Splices>
				<data:AvailableDucts>					<xsl:value-of select="cim:availableDucts"/>						</data:AvailableDucts>
				<data:UsedDucts>					<xsl:value-of select="cim:usedDucts"/>						</data:UsedDucts>
				<data:CollapsedDucts>					<xsl:value-of select="cim:collapsedDucts"/>						</data:CollapsedDucts>
				<data:AbandonedDucts>					<xsl:value-of select="cim:abandonedDucts"/>						</data:AbandonedDucts>
				<data:OtherDucts>					<xsl:value-of select="cim:otherDucts"/>						</data:OtherDucts>
				<data:DuctMaterial>					<xsl:value-of select="cim:ductMaterial"/>						</data:DuctMaterial>
				<data:ProtectiveDevice>					<xsl:value-of select="cim:protectiveDevice"/>						</data:ProtectiveDevice>

				
				
               <xsl:if test="count(cim:relatedPads/cim:EpcPad) >0">
                    <data:Pads>
                        <xsl:apply-templates select="cim:relatedPads/cim:EpcPad"/>
                    </data:Pads>
                </xsl:if>
               <xsl:if test="count(cim:relatedPedestals/cim:EpcPedestal) >0">
                    <data:Pedestals>
                        <xsl:apply-templates select="cim:relatedPedestals/cim:EpcPedestal"/>
                    </data:Pedestals>
                </xsl:if>
            <xsl:if test="count(cim:relatedDecorativePoles/cim:EpcDecorativePole) >0">
                <data:DecorativePoles>
                    <xsl:for-each select="cim:relatedDecorativePoles/cim:EpcDecorativePole">
                        <data:EpcDecorativePole>
                            <data:ID>
                                <xsl:value-of select="cim:mRID"/>
                            </data:ID>
                            <xsl:if test="count(cim:EO_mRID) > 0">
                                <data:EOID>
                                    <xsl:value-of select="cim:EO_mRID" />
                                </data:EOID>
                            </xsl:if>
                        </data:EpcDecorativePole>
                    </xsl:for-each>
                </data:DecorativePoles>
            </xsl:if>
            <xsl:if test="count(cim:relatedLuminaires/cim:EpcLuminaire) >0">
                <data:Luminaires>
                    <xsl:for-each select="cim:relatedLuminaires/cim:EpcLuminaire">
                        <data:EpcLuminaire>
                            <data:ID>
                                <xsl:value-of select="cim:mRID"/>
                            </data:ID>
                            <xsl:if test="count(cim:EO_mRID) > 0">
                                <data:EOID>
                                    <xsl:value-of select="cim:EO_mRID" />
                                </data:EOID>
                            </xsl:if>
                        </data:EpcLuminaire>
                    </xsl:for-each>
                </data:Luminaires>
            </xsl:if>
               <xsl:if test="count(cim:relatedVaults/cim:EpcVault) >0">
                    <data:Vaults>
                        <xsl:apply-templates select="cim:relatedVaults/cim:EpcVault"/>
                    </data:Vaults>
                </xsl:if>
               <xsl:if test="count(cim:relatedManholes/cim:EpcManhole) >0">
                    <data:Manholes>
                        <xsl:apply-templates select="cim:relatedManholes/cim:EpcManhole"/>
                    </data:Manholes>
                </xsl:if>
                <xsl:if test="count(cim:relatedConductors/cim:EpcConductor) >0">
                    <data:Conductors>
                        <xsl:apply-templates select="cim:relatedConductors/cim:EpcConductor"/>
                    </data:Conductors>
                </xsl:if>
            <xsl:if test="count(cim:relatedCables/cim:EpcCable) >0">
                <data:Cables>
                    <xsl:for-each select="cim:relatedCables/cim:EpcCable">
                        <data:Cable>
                            <data:ID>
                                <xsl:value-of select="cim:mRID" />
                            </data:ID>
                            <xsl:if test="count(cim:EO_mRID) > 0">
                                <data:EOID>
                                    <xsl:value-of select="cim:EO_mRID" />
                                </data:EOID>
                            </xsl:if>
                        </data:Cable>
                    </xsl:for-each>
                </data:Cables>
            </xsl:if>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
                <xsl:if test="count(cim:cables/cim:cable) > 0">
                    <data:EOCableRecords>
                        <xsl:for-each select="cim:cables/cim:cable">
                            <data:EOCableRecord>
                                <data:EO_mRID>
                                    <xsl:value-of select="cim:EO_mRID" />
                                </data:EO_mRID>
                                <data:Ivara_mRID>
                                    <xsl:value-of select="cim:Ivara_mRIDs/cim:Ivara_mRID" />
                                </data:Ivara_mRID>
                            </data:EOCableRecord>
                        </xsl:for-each>
                    </data:EOCableRecords>
                </xsl:if>
        </data:Conductor>
        <!--/xsl:if-->
    </xsl:template>
 
    <xsl:template match="cim:Circuit">
        <xsl:if test="boolean(string(./cim:mRID))">
            <data:Circuit>
                <data:ID>
                    <xsl:value-of select="concat('CIR-',./cim:mRID)"/>
                </data:ID>
                <xsl:if test="count(./cim:EO_mRID) > 0">
                    <data:EOID>
                        <xsl:value-of select="./cim:EO_mRID" />
                    </data:EOID>
                </xsl:if>
            </data:Circuit>
        </xsl:if>
    </xsl:template>
 
    <xsl:template match="cim:EpcVault">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
            <data:Vault>
                <data:UUID>
                    <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
                </data:UUID>
                <data:ID>
                    <xsl:value-of select="cim:mRID"/>
                </data:ID>
                <xsl:if test="count(cim:EO_mRID) > 0">
                    <data:EOID>
                        <xsl:value-of select="cim:EO_mRID" />
                    </data:EOID>
                </xsl:if>
                <data:Description>
                    <xsl:value-of select="cim:description"/>
                </data:Description>
                <data:AssetType>Vault</data:AssetType>
                <data:OwnerType>
                    <xsl:value-of select="cim:ownerType"/>
                </data:OwnerType>
                <data:OwnerName>
                    <xsl:value-of select="cim:ownerName"/>
                </data:OwnerName>
                <data:GeoLocation>
                    <data:Description>
                        <xsl:value-of select="cim:EpcLocation/cim:description"/>
                    </data:Description>
                    <data:X>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                    </data:X>
                    <data:Y>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                    </data:Y>
                    <data:Cadastral>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                    </data:Cadastral>
                    <data:Neighbourhood>
                        <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                    </data:Neighbourhood>
                    <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                    </data:NearestIntersection>
                </data:GeoLocation>
                <xsl:choose>
                    <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
                        <data:StartDate>
                            <xsl:value-of select="cim:startDate"/>
                        </data:StartDate>
                    </xsl:when>
                    <xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
                        <data:StartDate>
                            <xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
                        </data:StartDate>
                    </xsl:when>
                    <xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
                        <data:StartDate>
                            <xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
                        </data:StartDate>
                    </xsl:when>
                </xsl:choose>
                <xsl:if test="count(cim:Circuit) >0">
                    <data:Circuits>
                        <xsl:apply-templates select="cim:Circuit"/>
                    </data:Circuits>
                </xsl:if>
                <data:SourceStatus>
                    <xsl:choose>
                        <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="cim:Status/cim:value"/>
                        </xsl:otherwise>
                    </xsl:choose>
                </data:SourceStatus>
                <data:SourceType>
                    <xsl:choose>
                        <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                        <xsl:otherwise>
                            <xsl:value-of select="cim:epcSubCategory"/>
                        </xsl:otherwise>
                    </xsl:choose>
                </data:SourceType>
                <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                    <data:PreviousAsset>
                        <data:ID>
                            <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                        </data:ID>
                        <xsl:if test="count(cim:EpcAssetHistory/cim:EO_mRID) > 0">
                            <data:EOID>
                                <xsl:value-of select="cim:EpcAssetHistory/cim:EO_mRID" />
                            </data:EOID>
                        </xsl:if>
                    </data:PreviousAsset>
                </xsl:if>
                <data:VaultType>
                    <xsl:value-of select="cim:type"/>
                </data:VaultType>
                <data:WorkOrderNumber>
                    <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
                </data:WorkOrderNumber>
                <xsl:if test="count(cim:relatedTransformers/cim:EpcTransformer) >0">
                    <data:Transformers>
                        <xsl:apply-templates select="cim:relatedTransformers/cim:EpcTransformer"/>
                    </data:Transformers>
                </xsl:if>
            </data:Vault>
        <xsl:if test="count(cim:relatedCabinets/cim:EpcCabinet) >0">
            <data:Cabinets>
                <xsl:for-each select="cim:relatedCabinets/cim:EpcCabinet">
                    <data:Cabinet>
                        <data:ID>
                            <xsl:value-of select="cim:mRID" />
                        </data:ID>
                        <xsl:if test="count(cim:EO_mRID) > 0">
                            <data:EOID>
                                <xsl:value-of select="cim:EO_mRID" />
                            </data:EOID>
                        </xsl:if>
                    </data:Cabinet>
                </xsl:for-each>
            </data:Cabinets>
        </xsl:if>
        <xsl:if test="count(cim:relatedCables/cim:EpcCable) >0">
            <data:Cables>
                <xsl:for-each select="cim:relatedCables/cim:EpcCable">
                    <data:Cable>
                        <data:ID>
                            <xsl:value-of select="cim:mRID" />
                        </data:ID>
                        <xsl:if test="count(cim:EO_mRID) > 0">
                            <data:EOID>
                                <xsl:value-of select="cim:EO_mRID" />
                            </data:EOID>
                        </xsl:if>
                    </data:Cable>
                </xsl:for-each>
            </data:Cables>
        </xsl:if>
        <xsl:if test="count(cim:multiFamily) > 0">
            <data:MultiFamily>
                <xsl:value-of select="cim:multiFamily" />
            </data:MultiFamily>
        </xsl:if>
    </xsl:template>

    <xsl:template match="cim:EpcManhole">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:Manhole>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <xsl:if test="count(cim:EO_mRID) > 0">
                <data:EOID>
                    <xsl:value-of select="cim:EO_mRID" />
                </data:EOID>
            </xsl:if>
            <data:Name>
                <xsl:value-of select="cim:name"/>
            </data:Name>
            <data:Description>
                <xsl:value-of select="cim:description"/>
            </data:Description>
            <data:AssetType>Manhole</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <xsl:choose>
                <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="cim:startDate"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
            </xsl:choose>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                <data:PreviousAsset>
                    <data:ID>
                        <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                    </data:ID>
                    <xsl:if test="count(cim:EpcAssetHistory/cim:EO_mRID) > 0">
                        <data:EOID>
                            <xsl:value-of select="cim:EpcAssetHistory/cim:EO_mRID" />
                        </data:EOID>
                    </xsl:if>
                </data:PreviousAsset>
            </xsl:if>
            <data:ManholeType>
                <xsl:value-of select="cim:type"/>
            </data:ManholeType>
            <data:Usage>
                <xsl:value-of select="cim:usage"/>
            </data:Usage>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:if test="count(cim:relatedCables/cim:EpcCable) >0">
                <data:Cables>
                    <xsl:for-each select="cim:relatedCables/cim:EpcCable">
                        <data:Cable>
                            <data:ID>
                                <xsl:value-of select="cim:mRID" />
                            </data:ID>
                            <xsl:if test="count(cim:EO_mRID) > 0">
                                <data:EOID>
                                    <xsl:value-of select="cim:EO_mRID" />
                                </data:EOID>
                            </xsl:if>
                        </data:Cable>
                    </xsl:for-each>
                </data:Cables>
            </xsl:if>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
        </data:Manhole>
    </xsl:template>

    <xsl:template match="cim:EpcHandhole">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:Handhole>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <xsl:if test="count(cim:EO_mRID) > 0">
                <data:EOID>
                    <xsl:value-of select="cim:EO_mRID" />
                </data:EOID>
            </xsl:if>
            <data:Name>
                <xsl:value-of select="cim:name"/>
            </data:Name>
            <data:Description>
                <xsl:value-of select="cim:description"/>
            </data:Description>
            <data:AssetType>Handhole</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <xsl:choose>
                <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="cim:startDate"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
            </xsl:choose>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                <data:PreviousAsset>
                    <data:ID>
                        <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                    </data:ID>
                    <xsl:if test="count(cim:EpcAssetHistory/cim:EO_mRID) > 0">
                        <data:EOID>
                            <xsl:value-of select="cim:EpcAssetHistory/cim:EO_mRID" />
                        </data:EOID>
                    </xsl:if>
                </data:PreviousAsset>
            </xsl:if>
            <data:HandholeType>
                <xsl:value-of select="cim:type"/>
            </data:HandholeType>
            <data:Usage>
                <xsl:value-of select="cim:usage"/>
            </data:Usage>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:if test="count(cim:relatedCables/cim:EpcCable) >0">
                <data:Cables>
                    <xsl:for-each select="cim:relatedCables/cim:EpcCable">
                        <data:Cable>
                            <data:ID>
                                <xsl:value-of select="cim:mRID" />
                            </data:ID>
                            <xsl:if test="count(cim:EO_mRID) > 0">
                                <data:EOID>
                                    <xsl:value-of select="cim:EO_mRID" />
                                </data:EOID>
                            </xsl:if>
                        </data:Cable>
                    </xsl:for-each>
                </data:Cables>
            </xsl:if>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
        </data:Handhole>
    </xsl:template>

    <xsl:template match="cim:EpcPad">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:Pad>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <xsl:if test="count(cim:EO_mRID) > 0">
                <data:EOID>
                    <xsl:value-of select="cim:EO_mRID" />
                </data:EOID>
            </xsl:if>
            <xsl:if test="count(cim:type) > 0">
                <data:type>
                    <xsl:value-of select="cim:type" />
                </data:type>
            </xsl:if>
            <data:Name>
                <xsl:value-of select="cim:name"/>
            </data:Name>
            <data:Description>
                <xsl:value-of select="cim:description"/>
            </data:Description>
            <data:AssetType>Pad</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <xsl:choose>
                <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="cim:startDate"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
            </xsl:choose>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                <data:PreviousAsset>
                    <data:ID>
                        <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                    </data:ID>
                    <xsl:if test="count(cim:EpcAssetHistory/cim:EO_mRID) > 0">
                        <data:EOID>
                            <xsl:value-of select="cim:EpcAssetHistory/cim:EO_mRID" />
                        </data:EOID>
                    </xsl:if>
                </data:PreviousAsset>
            </xsl:if>
            <data:PadType>
                <xsl:value-of select="cim:type"/>
            </data:PadType>
            <data:Usage>
                <xsl:value-of select="cim:usage"/>
            </data:Usage>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:if test="count(cim:relatedCables/cim:EpcCable) >0">
                <data:Cables>
                    <xsl:for-each select="cim:relatedCables/cim:EpcCable">
                        <data:Cable>
                            <data:ID>
                                <xsl:value-of select="cim:mRID" />
                            </data:ID>
                            <xsl:if test="count(cim:EO_mRID) > 0">
                                <data:EOID>
                                    <xsl:value-of select="cim:EO_mRID" />
                                </data:EOID>
                            </xsl:if>
                        </data:Cable>
                    </xsl:for-each>
                </data:Cables>
            </xsl:if>
            <xsl:if test="count(cim:relatedTransformers/cim:EpcTransformer) >0">
                <data:Transformers>
                    <xsl:apply-templates select="cim:relatedTransformers/cim:EpcTransformer"/>
                </data:Transformers>
            </xsl:if>
            <xsl:if test="boolean(string(cim:cabinetDepartmentNumber))">
                <data:Cabinets>
                    <data:Cabinet>
                        <data:ID>
                            <xsl:value-of select="cim:cabinetDepartmentNumber"/>
                        </data:ID>
                    </data:Cabinet>
                </data:Cabinets>
            </xsl:if>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
        </data:Pad>
    </xsl:template>

    <xsl:template match="cim:EpcPedestal">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:Pedestal>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <xsl:if test="count(cim:EO_mRID) > 0">
                <data:EOID>
                    <xsl:value-of select="cim:EO_mRID" />
                </data:EOID>
            </xsl:if>
            <data:Name>
                <xsl:value-of select="cim:name"/>
            </data:Name>
            <data:Description>
                <xsl:value-of select="cim:description"/>
            </data:Description>
            <data:AssetType>Pedestal</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <xsl:choose>
                <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="cim:startDate"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
            </xsl:choose>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                <data:PreviousAsset>
                    <data:ID>
                        <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                    </data:ID>
                    <xsl:if test="count(cim:EpcAssetHistory/cim:EO_mRID) > 0">
                        <data:EOID>
                            <xsl:value-of select="cim:EpcAssetHistory/cim:EO_mRID" />
                        </data:EOID>
                    </xsl:if>
                </data:PreviousAsset>
            </xsl:if>
            <data:PedestalType>
                <xsl:value-of select="cim:type"/>
            </data:PedestalType>
            <data:Usage>
                <xsl:value-of select="cim:usage"/>
            </data:Usage>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
        </data:Pedestal>
    </xsl:template>


    <xsl:template match="cim:EpcDecorativePole">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:DecorativePole>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <xsl:if test="count(cim:EO_mRID) > 0">
                <data:EOID>
                    <xsl:value-of select="cim:EO_mRID" />
                </data:EOID>
            </xsl:if>
            <data:Name>
                <xsl:value-of select="cim:name"/>
            </data:Name>
            <data:Description>
                <xsl:value-of select="cim:description"/>
            </data:Description>
            <data:AssetType>DecorativePole</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:choose>
                <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="cim:startDate"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
            </xsl:choose>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                <data:PreviousAsset>
                    <data:ID>
                        <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                    </data:ID>
                    <xsl:if test="count(cim:EO_mRID) > 0">
                        <data:EOID>
                            <xsl:value-of select="cim:EO_mRID" />
                        </data:EOID>
                    </xsl:if>
                </data:PreviousAsset>
            </xsl:if>
            <data:DecorativePoleType>
                <xsl:value-of select="cim:type"/>
            </data:DecorativePoleType>
            <data:Usage>
                <xsl:value-of select="cim:usage"/>
            </data:Usage>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
            <xsl:if test="count(cim:EpcWorkOrder/cim:workOrderYear) >0">
                <data:WorkOrderYear>
                    <xsl:value-of select="cim:EpcWorkOrder/cim:workOrderYear"/>
                </data:WorkOrderYear>
            </xsl:if>
            <xsl:if test="count(cim:poleHeight) >0">
                <data:PoleHeight>
                    <xsl:value-of select="cim:poleHeight" />
                </data:PoleHeight>
            </xsl:if>
            <xsl:if test="count(cim:decorativePoleType) >0">
                <data:DecorativePoleType>
                    <xsl:value-of select="cim:decorativePoleType" />
                </data:DecorativePoleType>
            </xsl:if>
            <xsl:if test="count(cim:material) >0">
                <data:Material>
                    <xsl:value-of select="cim:material" />
                </data:Material>
            </xsl:if>
            <xsl:if test="count(cim:totalForeignAttachments) >0">
                <data:TotalForeignAttachments>
                    <xsl:value-of select="cim:totalForeignAttachments" />
                </data:TotalForeignAttachments>
            </xsl:if>
            <xsl:if test="count(cim:phasing) >0">
                <data:Phasing>
                    <xsl:value-of select="cim:phasing" />
                </data:Phasing>
            </xsl:if>
            <xsl:if test="count(cim:siteId) >0">
                <data:SiteId>
                    <xsl:value-of select="cim:siteId" />
                </data:SiteId>
            </xsl:if>
            <xsl:if test="count(cim:siteEnergizeStatus) >0">
                <data:SiteEnergizeStatus>
                    <xsl:value-of select="cim:siteEnergizeStatus" />
                </data:SiteEnergizeStatus>
            </xsl:if>
            <xsl:if test="count(cim:siteAddress) >0">
                <data:SiteAddress>
                    <xsl:value-of select="cim:siteAddress" />
                </data:SiteAddress>
            </xsl:if>
        </data:DecorativePole>
    </xsl:template>

    <xsl:template match="cim:EpcAerialWire">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:AerialWire>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <data:Name>
                <xsl:value-of select="cim:name"/>
            </data:Name>
            <data:Description>
                <xsl:value-of select="cim:description"/>
            </data:Description>
            <data:AssetType>AerialWire</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:choose>
                <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="cim:startDate"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
            </xsl:choose>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                <data:PreviousAsset>
                    <data:ID>
                        <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                    </data:ID>
                </data:PreviousAsset>
            </xsl:if>
            <xsl:if test="count(cim:EpcWorkOrder/cim:workOrderYear) >0">
                <data:WorkOrderYear>
                    <xsl:value-of select="cim:EpcWorkOrder/cim:workOrderYear"/>
                </data:WorkOrderYear>
            </xsl:if>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
        </data:AerialWire>
    </xsl:template>


    <xsl:template match="cim:EpcLuminaire">
        <xsl:variable name="uuid" select="oraext:generate-guid()"/>
        <data:Luminaire>
            <data:UUID>
                <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
            </data:UUID>
            <data:ID>
                <xsl:value-of select="cim:mRID"/>
            </data:ID>
            <xsl:if test="count(cim:EO_mRID) > 0">
                <data:EOID>
                    <xsl:value-of select="cim:EO_mRID" />
                </data:EOID>
            </xsl:if>
            <data:Name>
                <xsl:value-of select="cim:name"/>
            </data:Name>
            <data:Description>
                <xsl:value-of select="cim:description"/>
            </data:Description>
            <data:AssetType>Luminaire</data:AssetType>
            <data:OwnerType>
                <xsl:value-of select="cim:ownerType"/>
            </data:OwnerType>
            <data:OwnerName>
                <xsl:value-of select="cim:ownerName"/>
            </data:OwnerName>
            <data:GeoLocation>
                <data:Description>
                    <xsl:value-of select="cim:EpcLocation/cim:description"/>
                </data:Description>
                <data:X>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:x"/>
                </data:X>
                <data:Y>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:y"/>
                </data:Y>
                <data:Cadastral>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:cadastral"/>
                </data:Cadastral>
                <data:Neighbourhood>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:neighbourhood"/>
                </data:Neighbourhood>
                <data:NearestIntersection>
                    <xsl:value-of select="cim:EpcLocation/cim:geoAddress/cim:nearestIntersection"/>
                </data:NearestIntersection>
            </data:GeoLocation>
            <data:WorkOrderNumber>
                <xsl:value-of select="cim:EpcWorkOrder/cim:mRID"/>
            </data:WorkOrderNumber>
            <xsl:choose>
                <xsl:when test="boolean(string(cim:startDate)) and xp20:matches(cim:startDate,'\d{4}') and number(cim:startDate) > 1900 and number(cim:startDate)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="cim:startDate"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:EpcWorkOrder/cim:workOrderYear)) and xp20:matches(cim:EpcWorkOrder/cim:workOrderYear,'^\d{4}$') and number(cim:EpcWorkOrder/cim:workOrderYear) > 1900 and number(cim:EpcWorkOrder/cim:workOrderYear)&lt;=number($year)">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:EpcWorkOrder/cim:workOrderYear,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
                <xsl:when test="boolean(string(cim:derivedVintage)) and xp20:matches(cim:derivedVintage,'^\d{4}$') and number(cim:derivedVintage) > 1900">
                    <data:StartDate>
                        <xsl:value-of select="concat(cim:derivedVintage,'-01-01')"/>
                    </data:StartDate>
                </xsl:when>
            </xsl:choose>
            <xsl:if test="count(cim:Circuit) >0">
                <data:Circuits>
                    <xsl:apply-templates select="cim:Circuit"/>
                </data:Circuits>
            </xsl:if>
            <data:SourceStatus>
                <xsl:choose>
                    <xsl:when test="cim:epcSubCategory='delete'">Removed</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:Status/cim:value"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceStatus>
            <data:SourceType>
                <xsl:choose>
                    <xsl:when test="cim:Status/cim:value='Removed'">delete</xsl:when>
                    <xsl:otherwise>
                        <xsl:value-of select="cim:epcSubCategory"/>
                    </xsl:otherwise>
                </xsl:choose>
            </data:SourceType>
            <xsl:if test="boolean(string(cim:EpcAssetHistory/cim:mRID))">
                <data:PreviousAsset>
                    <data:ID>
                        <xsl:value-of select="cim:EpcAssetHistory/cim:mRID"/>
                    </data:ID>
                    <xsl:if test="count(cim:EpcAssetHistory/cim:EO_mRID) > 0">
                        <data:EOID>
                            <xsl:value-of select="cim:EpcAssetHistory/cim:EO_mRID" />
                        </data:EOID>
                    </xsl:if>
                </data:PreviousAsset>
            </xsl:if>
            <data:PedestalType>
                <xsl:value-of select="cim:type"/>
            </data:PedestalType>
            <data:LuminaireType>
                <xsl:value-of select="cim:type"/>
            </data:LuminaireType>
            <data:Usage>
                <xsl:value-of select="cim:usage"/>
            </data:Usage>
            <xsl:if test="count(cim:multiFamily) > 0">
                <data:MultiFamily>
                    <xsl:value-of select="cim:multiFamily" />
                </data:MultiFamily>
            </xsl:if>
            <!-- Luminaire-specific -->
            <xsl:if test="count(cim:EpcWorkOrder/cim:workOrderYear) >0">
                <data:WorkOrderYear>
                    <xsl:value-of select="cim:EpcWorkOrder/cim:workOrderYear"/>
                </data:WorkOrderYear>
            </xsl:if>
            <xsl:if test="count(cim:manufacturer) >0">
                <data:Manufacturer>
                    <xsl:value-of select="cim:manufacturer"/>
                </data:Manufacturer>
            </xsl:if>
            <xsl:if test="count(cim:controlType) >0">
                <data:ControlType>
                    <xsl:value-of select="cim:controlType" />
                </data:ControlType>
            </xsl:if>
            <xsl:if test="count(cim:lampType) >0">
                <data:LampType>
                    <xsl:value-of select="cim:lampType" />
                </data:LampType>
            </xsl:if>
            <xsl:if test="count(cim:nominalVoltagePP) >0">
                <data:NominalVoltagePP>
                    <xsl:value-of select="cim:nominalVoltagePP" />
                </data:NominalVoltagePP>
            </xsl:if>
            <xsl:if test="count(cim:nominalVoltagePN) >0">
                <data:NominalVoltagePN>
                    <xsl:value-of select="cim:nominalVoltagePN" />
                </data:NominalVoltagePN>
            </xsl:if>
            <xsl:if test="count(cim:powerConsumption) >0">
                <data:PowerConsumption>
                    <xsl:value-of select="cim:powerConsumption" />
                </data:PowerConsumption>
            </xsl:if>
            <xsl:if test="count(cim:lightLumens) >0">
                <data:LightLumens>
                    <xsl:value-of select="cim:lightLumens" />
                </data:LightLumens>
            </xsl:if>
            <xsl:if test="count(cim:siteId) >0">
                <data:SiteId>
                    <xsl:value-of select="cim:siteId" />
                </data:SiteId>
            </xsl:if>
            <xsl:if test="count(cim:siteEnergizeStatus) >0">
                <data:SiteEnergizeStatus>
                    <xsl:value-of select="cim:siteEnergizeStatus" />
                </data:SiteEnergizeStatus>
            </xsl:if>
            <xsl:if test="count(cim:siteAddress) >0">
                <data:SiteAddress>
                    <xsl:value-of select="cim:siteAddress" />
                </data:SiteAddress>
            </xsl:if>
        </data:Luminaire>
    </xsl:template>

</xsl:stylesheet>
