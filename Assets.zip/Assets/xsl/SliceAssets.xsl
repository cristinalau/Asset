<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:ehdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.esb.server.headers.ESBHeaderFunctions" xmlns:ebs="http://xmlns.oracle.com/pcbpel/adapter/db/EBSPoles" xmlns:common="urn:epcor:as:Common" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" exclude-result-prefixes="xsl types xsd bpws xp20 xref orcl ora hwf ids ehdr ebs xsi dvm common" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
                
   <xsl:param name="reprocessControl"/>
   
   <xsl:template match="/data:Poles">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:PolesRequestMediator>
         <data:Poles>
            <xsl:for-each select="data:Pole">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Poles>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:PolesRequestMediator>
   </xsl:template>

   <xsl:template match="/data:TransPoles">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:TransPolesRequestMediator>
         <data:TransPoles>
            <xsl:for-each select="data:TransPole">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:TransPoles>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:TransPolesRequestMediator>
   </xsl:template>
    <xsl:template match="/data:TransStructures">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:TransStructuresRequestMediator>
         <data:TransStructures>
            <xsl:for-each select="data:TransStructure">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:TransStructures>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:TransStructuresRequestMediator>
   </xsl:template>
  
 <xsl:template match="/data:Pads">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:PadsRequestMediator>
         <data:Pads>
            <xsl:for-each select="data:Pad">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Pads>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:PadsRequestMediator>
   </xsl:template>

   <xsl:template match="/data:Pedestals">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:PedestalsRequestMediator>
         <data:Pedestals>
            <xsl:for-each select="data:Pedestal">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Pedestals>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:PedestalsRequestMediator>
   </xsl:template>

   <xsl:template match="/data:DecorativePoles">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:DecorativePolesRequestMediator>
         <data:DecorativePoles>
            <xsl:for-each select="data:DecorativePole">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:DecorativePoles>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:DecorativePolesRequestMediator>
   </xsl:template>

   <xsl:template match="/data:AerialWires">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:AerialWiresRequestMediator>
         <data:AerialWires>
            <xsl:for-each select="data:AerialWire">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:AerialWires>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:AerialWiresRequestMediator>
   </xsl:template>

   <xsl:template match="/data:Luminaires">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:LuminairesRequestMediator>
         <data:Luminaires>
            <xsl:for-each select="data:Luminaire">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Luminaires>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:LuminairesRequestMediator>
   </xsl:template>

   <xsl:template match="/data:Vaults">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:VaultsRequestMediator>
         <data:Vaults>
            <xsl:for-each select="data:Vault">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Vaults>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:VaultsRequestMediator>
   </xsl:template>

   <xsl:template match="/data:Manholes">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:ManholesRequestMediator>
         <data:Manholes>
            <xsl:for-each select="data:Manhole">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Manholes>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:ManholesRequestMediator>
   </xsl:template>

   <xsl:template match="/data:Handholes">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:HandholesRequestMediator>
         <data:Handholes>
            <xsl:for-each select="data:Handhole">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Handholes>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:HandholesRequestMediator>
   </xsl:template>

   <xsl:template match="/data:AerialSwitches">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:AerialSwitchesRequestMediator>
         <data:AerialSwitches>
            <xsl:for-each select="data:AerialSwitch">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:AerialSwitches>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:AerialSwitchesRequestMediator>
   </xsl:template>

   <xsl:template match="/data:Transformers">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:TransformersRequestMediator>
         <data:Transformers>
            <xsl:for-each select="data:Transformer">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Transformers>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:TransformersRequestMediator>
   </xsl:template>

   <xsl:template match="/data:Cabinets">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:CabinetsRequestMediator>
         <data:Cabinets>
            <xsl:for-each select="data:Cabinet">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Cabinets>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:CabinetsRequestMediator>
   </xsl:template>

 <xsl:template match="/data:Conductors">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:ConductorsRequestMediator>
         <data:Conductors>
            <xsl:for-each select="data:Conductor">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Conductors>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:ConductorsRequestMediator>
   </xsl:template>
   
 <xsl:template match="/data:Cables">
      <xsl:variable name="session" select="oraext:generate-guid()"/>
      <data:CablesRequestMediator>
         <data:Cables>
            <xsl:for-each select="data:Cable">
               <xsl:if test="position() > $reprocessControl/common:reprocessControl/common:processedCount and position() &lt;= ($reprocessControl/common:reprocessControl/common:processedCount + $reprocessControl/common:reprocessControl/common:cacheSize)">
                  <xsl:copy-of select="."/>
               </xsl:if>
            </xsl:for-each>
         </data:Cables>
         <data:Session>
            <xsl:value-of select="concat(substring($session,1,8),'-',substring($session,9,4),'-',substring($session,13,4),'-',substring($session,17,4),'-',substring($session,20,12))"/>
         </data:Session>
      </data:CablesRequestMediator>
   </xsl:template>


   

</xsl:stylesheet>
