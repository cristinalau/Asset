<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:ehdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.esb.server.headers.ESBHeaderFunctions" xmlns:common="urn:epcor:as:Common" exclude-result-prefixes="xsl types tns xsd bpws xp20 xref orcl ora hwf ids ehdr dvm common" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
                
    <xsl:param name="allAssets"/>
    
    <xsl:template match="/data:AssetReprocessSet">
        <data:Assets>
            <xsl:for-each select="data:Poles/data:Pole">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                     <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="data:Height"/>
                     <xsl:copy-of select="data:FrameType"/>
                     <xsl:copy-of select="data:Class"/>
                     <xsl:copy-of select="data:Usage"/>
                     <xsl:copy-of select="data:Material"/>
                     <xsl:copy-of select="data:Treatment"/>
                     <xsl:copy-of select="data:Remark"/>
                     <xsl:copy-of select="data:ReinforcementType"/>
                     <xsl:copy-of select="data:DeadEndIndicator"/>
                     <xsl:copy-of select="data:Phases"/>
                     <xsl:copy-of select="data:FiberOptics"/>
                     <xsl:copy-of select="data:WorkOrderNumber"/>
                     <xsl:copy-of select="data:TotalForeignAttachments"/>
                     <xsl:copy-of select="data:Transformers"/>
                     <xsl:copy-of select="data:Grouping"/>
                     <xsl:copy-of select="data:AerialSwitches"/>
                </data:Asset>
                </xsl:if>
            </xsl:for-each>

            <xsl:for-each select="data:TransPoles/data:TransPole">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="data:Height"/>
                     <xsl:copy-of select="data:FrameType"/>
                     <xsl:copy-of select="data:Class"/>
                     <xsl:copy-of select="data:Usage"/>
                     <xsl:copy-of select="data:Material"/>
                     <xsl:copy-of select="data:Treatment"/>
                     <xsl:copy-of select="data:Remark"/>
                     <xsl:copy-of select="data:ReinforcementType"/>
                     <xsl:copy-of select="data:DeadEndIndicator"/>
                     <xsl:copy-of select="data:Phases"/>
                     <xsl:copy-of select="data:FiberOptics"/>
                     <xsl:copy-of select="data:WorkOrderNumber"/>
                     <xsl:copy-of select="data:TotalForeignAttachments"/>
                     <xsl:copy-of select="data:Transformers"/>
                     <xsl:copy-of select="data:Grouping"/>
                     <xsl:copy-of select="data:AerialSwitches"/>
					 <xsl:copy-of select="data:Configuration"/>
					<xsl:copy-of select="data:DateInstalled"/>
               </data:Asset>
                </xsl:if>
            </xsl:for-each>

           <xsl:for-each select="data:TransStructures/data:TransStructure">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="data:Height"/>
                     <xsl:copy-of select="data:FrameType"/>
                     <xsl:copy-of select="data:Class"/>
                     <xsl:copy-of select="data:Usage"/>
                     <xsl:copy-of select="data:Material"/>
                     <xsl:copy-of select="data:Treatment"/>
                     <xsl:copy-of select="data:Remark"/>
                     <xsl:copy-of select="data:ReinforcementType"/>
                     <xsl:copy-of select="data:DeadEndIndicator"/>
                     <xsl:copy-of select="data:Phases"/>
                     <xsl:copy-of select="data:FiberOptics"/>
                     <xsl:copy-of select="data:WorkOrderNumber"/>
                     <xsl:copy-of select="data:TotalForeignAttachments"/>
                     <xsl:copy-of select="data:Transformers"/>
                     <xsl:copy-of select="data:Grouping"/>
                     <xsl:copy-of select="data:AerialSwitches"/>
					 <xsl:copy-of select="data:Configuration"/>
					<xsl:copy-of select="data:DateInstalled"/>
               </data:Asset>
                </xsl:if>
            </xsl:for-each>
			
            <xsl:for-each select="data:Pads/data:Pad">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="data:FiberOptics"/>
                     <xsl:copy-of select="data:WorkOrderNumber"/>
                     <xsl:copy-of select="data:Transformers"/>
                     <xsl:copy-of select="data:Cabinets"/>
                </data:Asset>
                </xsl:if>
            </xsl:for-each>
            <xsl:for-each select="data:Pedestals/data:Pedestal">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="data:FiberOptics"/>
                     <xsl:copy-of select="data:WorkOrderNumber"/>
                     <xsl:copy-of select="data:Transformers"/>
                     <xsl:copy-of select="data:Cabinets"/>
                </data:Asset>
                </xsl:if>
            </xsl:for-each>
            <xsl:for-each select="data:DecorativePoles/data:DecorativePole">
                <xsl:if test="data:ErrorCode!=0">
                    <data:Asset>
                        <xsl:copy-of select="data:UUID"/>
                        <xsl:copy-of select="data:ID"/>
                        <xsl:copy-of select="data:AssetType"/>
                        <xsl:copy-of select="data:OwnerType"/>
                        <xsl:copy-of select="data:OwnerName"/>
                        <xsl:copy-of select="data:GeoLocation"/>
                        <xsl:copy-of select="data:StartDate"/>
                        <xsl:copy-of select="data:Circuits"/>
                        <xsl:copy-of select="data:SourceStatus"/>
                        <xsl:copy-of select="data:SourceType"/>
                        <xsl:copy-of select="data:MultiFamily"/>
                        <xsl:copy-of select="data:PreviousAsset"/>
                        <xsl:copy-of select="data:ProcessedDate"/>
                        <xsl:copy-of select="data:ErrorCode"/>
                        <xsl:copy-of select="data:ErrorText"/>
                        <data:Action>TBD</data:Action>
                        <xsl:copy-of select="data:PoleHeight" />
                        <xsl:copy-of select="data:DecorativePoleType" />
                        <xsl:copy-of select="data:Material" />
                        <xsl:copy-of select="data:TotalForeignAttachments" />
                        <xsl:copy-of select="data:Phasing" />
                        <xsl:copy-of select="data:SiteId" />
                        <xsl:copy-of select="data:SiteEnergizeStatus" />
                        <xsl:copy-of select="data:SiteAddress" />
                        <xsl:copy-of select="data:Luminaires" />
                    </data:Asset>
                </xsl:if>
            </xsl:for-each>
            <xsl:for-each select="data:AerialWires/data:AerialWire">
                <xsl:if test="data:ErrorCode!=0">
                    <data:Asset>
                        <!-- TODO:  Aerial Wire -->
                        <xsl:copy-of select="data:UUID"/>
                        <xsl:copy-of select="data:ID"/>
                        <xsl:copy-of select="data:AssetType"/>
                        <xsl:copy-of select="data:OwnerType"/>
                        <xsl:copy-of select="data:OwnerName"/>
                        <xsl:copy-of select="data:GeoLocation"/>
                        <xsl:copy-of select="data:StartDate"/>
                        <xsl:copy-of select="data:Circuits"/>
                        <xsl:copy-of select="data:SourceStatus"/>
                        <xsl:copy-of select="data:SourceType"/>
                        <xsl:copy-of select="data:MultiFamily"/>
                        <xsl:copy-of select="data:PreviousAsset"/>
                        <xsl:copy-of select="data:ProcessedDate"/>
                        <xsl:copy-of select="data:ErrorCode"/>
                        <xsl:copy-of select="data:ErrorText"/>
                        <data:Action>TBD</data:Action>
                        <!-- TODO:  Aerial Wire -->
                    </data:Asset>
                </xsl:if>
            </xsl:for-each>
            <xsl:for-each select="data:Luminaires/data:Luminaire">
                <xsl:if test="data:ErrorCode!=0">
                    <data:Asset>
                        <xsl:copy-of select="data:UUID"/>
                        <xsl:copy-of select="data:ID"/>
                        <xsl:copy-of select="data:AssetType"/>
                        <xsl:copy-of select="data:OwnerType"/>
                        <xsl:copy-of select="data:OwnerName"/>
                        <xsl:copy-of select="data:GeoLocation"/>
                        <xsl:copy-of select="data:StartDate"/>
                        <xsl:copy-of select="data:Circuits"/>
                        <xsl:copy-of select="data:SourceStatus"/>
                        <xsl:copy-of select="data:SourceType"/>
                        <xsl:copy-of select="data:MultiFamily"/>
                        <xsl:copy-of select="data:PreviousAsset"/>
                        <xsl:copy-of select="data:ProcessedDate"/>
                        <xsl:copy-of select="data:ErrorCode"/>
                        <xsl:copy-of select="data:ErrorText"/>
                        <data:Action>TBD</data:Action>
                        <xsl:copy-of select="data:Manufacturer"/>
                        <xsl:copy-of select="data:ControlType" />
                        <xsl:copy-of select="data:LampType" />
                        <xsl:copy-of select="data:NominalVoltagePP" />
                        <xsl:copy-of select="data:NominalVoltagePN" />
                        <xsl:copy-of select="data:PowerConsumption" />
                        <xsl:copy-of select="data:LightLumens" />
                        <xsl:copy-of select="data:SiteId"/>
                        <xsl:copy-of select="data:SiteEnergizeStatus"/>
                        <xsl:copy-of select="data:SiteAddress"/>
                        <xsl:copy-of select="data:Poles" />
                        <xsl:copy-of select="data:DecorativePoles" />
                    </data:Asset>
                </xsl:if>
            </xsl:for-each>

            <xsl:for-each select="data:Vaults/data:Vault">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="data:FiberOptics"/>
                     <xsl:copy-of select="data:VaultType"/>
                     <xsl:copy-of select="data:WorkOrderNumber"/>
                     <xsl:copy-of select="data:Transformers"/>
                     <xsl:copy-of select="data:Cabinets"/>
                </data:Asset>
                </xsl:if>
            </xsl:for-each>
            <xsl:for-each select="data:Manholes/data:Manhole">
                <xsl:if test="data:ErrorCode!=0">
                    <data:Asset>
                        <xsl:copy-of select="data:UUID"/>
                        <xsl:copy-of select="data:ID"/>
                        <xsl:copy-of select="data:AssetType"/>
                        <xsl:copy-of select="data:OwnerType"/>
                        <xsl:copy-of select="data:OwnerName"/>
                        <xsl:copy-of select="data:GeoLocation"/>
                        <xsl:copy-of select="data:StartDate"/>
                        <xsl:copy-of select="data:Circuits"/>
                        <xsl:copy-of select="data:SourceStatus"/>
                        <xsl:copy-of select="data:SourceType"/>
                        <xsl:copy-of select="data:MultiFamily" />
                        <xsl:copy-of select="data:PreviousAsset"/>
                        <xsl:copy-of select="data:ProcessedDate"/>
                        <xsl:copy-of select="data:ErrorCode"/>
                        <xsl:copy-of select="data:ErrorText"/>
                        <data:Action>TBD</data:Action>
                        <xsl:copy-of select="data:Site"/>
                        <xsl:copy-of select="data:ManholeType"/>
                        <xsl:copy-of select="data:Usage"/>
                        <xsl:copy-of select="data:WorkOrderNumber"/>
                    </data:Asset>
                </xsl:if>
            </xsl:for-each>
            <xsl:for-each select="data:Handholes/data:Handhole">
                <xsl:if test="data:ErrorCode!=0">
                    <data:Asset>
                        <xsl:copy-of select="data:UUID"/>
                        <xsl:copy-of select="data:ID"/>
                        <xsl:copy-of select="data:AssetType"/>
                        <xsl:copy-of select="data:OwnerType"/>
                        <xsl:copy-of select="data:OwnerName"/>
                        <xsl:copy-of select="data:GeoLocation"/>
                        <xsl:copy-of select="data:StartDate"/>
                        <xsl:copy-of select="data:Circuits"/>
                        <xsl:copy-of select="data:SourceStatus"/>
                        <xsl:copy-of select="data:SourceType"/>
                        <xsl:copy-of select="data:MultiFamily" />
                        <xsl:copy-of select="data:PreviousAsset"/>
                        <xsl:copy-of select="data:ProcessedDate"/>
                        <xsl:copy-of select="data:ErrorCode"/>
                        <xsl:copy-of select="data:ErrorText"/>
                        <data:Action>TBD</data:Action>
                        <xsl:copy-of select="data:Site"/>
                        <xsl:copy-of select="data:HandholeType"/>
                        <xsl:copy-of select="data:Usage"/>
                        <xsl:copy-of select="data:WorkOrderNumber"/>
                    </data:Asset>
                </xsl:if>
            </xsl:for-each>
            <xsl:for-each select="data:AerialSwitches/data:AerialSwitch">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="data:AerialSwitchType"/>
                     <xsl:copy-of select="data:NormalStatus"/>
                     <xsl:copy-of select="data:Phasing"/>
                     <xsl:copy-of select="data:Mounting"/>
                     <xsl:copy-of select="data:VoltageRating"/>
                     <xsl:copy-of select="data:ContinuousAmpRating"/>
                     <xsl:copy-of select="data:FuseUnits"/>
                     <xsl:copy-of select="data:SwitchUnits"/>
                     <xsl:copy-of select="data:SwitchSize"/>
                     <xsl:copy-of select="data:LoadBreak"/>
                     <xsl:copy-of select="data:VendorName"/>
                     <xsl:copy-of select="data:WorkOrderNumber"/>
                     <xsl:copy-of select="data:Poles"/>

                     <xsl:copy-of select="data:CircuitTieIndicator"/>
                     <xsl:copy-of select="data:Grouping"/>
                </data:Asset>
                </xsl:if>
            </xsl:for-each>
            <xsl:for-each select="data:Transformers/data:Transformer">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="data:Category"/>
                     <xsl:copy-of select="data:BankConfiguration"/>
                     <xsl:copy-of select="data:ServiceIPPIndicator"/>
                     <xsl:copy-of select="data:SpecialLoading"/>
                     <xsl:copy-of select="data:TransformerType"/>
                     <xsl:copy-of select="data:DemandPoints"/>
                     <xsl:copy-of select="data:WorkOrderNumber"/>
                     <xsl:copy-of select="data:Poles"/>
                     <xsl:copy-of select="data:Cables"/>
                    <xsl:copy-of select="data:Pedestals"/>
                    <xsl:copy-of select="data:DecorativePoles"/>
                    <xsl:copy-of select="data:Luminaires"/>
                    <xsl:copy-of select="data:Vaults"/>
                </data:Asset>
                </xsl:if>
            </xsl:for-each>
            <xsl:for-each select="data:Cabinets/data:Cabinet">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="data:LiveFrontIndicator"/>
                     <xsl:copy-of select="data:CabinetType"/>
                     <xsl:copy-of select="data:WorkOrderNumber"/>
                     <xsl:copy-of select="data:Pads"/>
                    <xsl:copy-of select="data:Pedestals"/>
                    <xsl:copy-of select="data:DecorativePoles"/>
                    <xsl:copy-of select="data:Luminaires"/>
                </data:Asset>
                </xsl:if>
            </xsl:for-each>
          <xsl:for-each select="data:Conductors/data:Conductor">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                    <xsl:copy-of select="data:UUID"/>
                    <xsl:copy-of select="data:ID"/>
                    <xsl:copy-of select="data:AssetType"/>
                    <xsl:copy-of select="data:OwnerType"/>
                    <xsl:copy-of select="data:OwnerName"/>
                    <xsl:copy-of select="data:GeoLocation"/>
                    <xsl:copy-of select="data:StartDate"/>
                    <xsl:copy-of select="data:Circuits"/>
                    <xsl:copy-of select="data:SourceStatus"/>
                    <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                    <xsl:copy-of select="data:PreviousAsset"/>
                    <xsl:copy-of select="data:ProcessedDate"/>
                    <xsl:copy-of select="data:ErrorCode"/>
                    <xsl:copy-of select="data:ErrorText"/>
                    <data:Action>TBD</data:Action>
                    <xsl:copy-of select="data:Site"/>
                    <xsl:copy-of select="Insulation"/>
                    <xsl:copy-of select="Arrangement"/>
                    <xsl:copy-of select="CalculatedLength"/>
                    <xsl:copy-of select="EpcInjectable"/>
                    <xsl:copy-of select="EpcInjectedDate"/>
                    <xsl:copy-of select="EpcInjectionMethod"/>
                    <xsl:copy-of select="NeutralConfiguration"/>
                    <xsl:copy-of select="NominalVoltage"/>
                    <xsl:copy-of select="OutsideDiameter"/>
                    <xsl:copy-of select="RatedVoltage"/>
                    <xsl:copy-of select="RepairSplices"/>
                    <xsl:copy-of select="Size"/>
                    <xsl:copy-of select="Splices"/>
                    <xsl:copy-of select="AvailableDucts"/>
                    <xsl:copy-of select="UsedDucts"/>
                    <xsl:copy-of select="CollapsedDucts"/>
                    <xsl:copy-of select="AbandonedDucts"/>
                    <xsl:copy-of select="OtherDucts"/>
                    <xsl:copy-of select="DuctMaterial"/>
                    <xsl:copy-of select="ProtectiveDevice"/>
                </data:Asset>
                </xsl:if>
            </xsl:for-each>

            <xsl:for-each select="data:Cables/data:Cable">
                <xsl:if test="data:ErrorCode!=0">
                <data:Asset>
                     <xsl:copy-of select="data:UUID"/>
                     <xsl:copy-of select="data:ID"/>
                     <xsl:copy-of select="data:AssetType"/>
                     <xsl:copy-of select="data:OwnerType"/>
                     <xsl:copy-of select="data:OwnerName"/>
                     <xsl:copy-of select="data:GeoLocation"/>
                     <xsl:copy-of select="data:StartDate"/>
                     <xsl:copy-of select="data:Circuits"/>
                     <xsl:copy-of select="data:SourceStatus"/>
                     <xsl:copy-of select="data:SourceType"/>
                    <xsl:copy-of select="data:MultiFamily" />
                     <xsl:copy-of select="data:PreviousAsset"/>
                     <xsl:copy-of select="data:ProcessedDate"/>
                     <xsl:copy-of select="data:ErrorCode"/>
                     <xsl:copy-of select="data:ErrorText"/>
                     <data:Action>TBD</data:Action>
                     <xsl:copy-of select="data:Site"/>
                     <xsl:copy-of select="Insulation"/>
                     <xsl:copy-of select="Arrangement"/>
                     <xsl:copy-of select="CalculatedLength"/>
                     <xsl:copy-of select="EpcInjectable"/>
                     <xsl:copy-of select="EpcInjectedDate"/>
                     <xsl:copy-of select="EpcInjectionMethod"/>
                     <xsl:copy-of select="NeutralConfiguration"/>
                     <xsl:copy-of select="NominalVoltage"/>
                     <xsl:copy-of select="OutsideDiameter"/>
                     <xsl:copy-of select="RatedVoltage"/>
                     <xsl:copy-of select="RepairSplices"/>
                     <xsl:copy-of select="Size"/>
                     <xsl:copy-of select="Splices"/>
                     <xsl:copy-of select="AvailableDucts"/>
                     <xsl:copy-of select="UsedDucts"/>
                     <xsl:copy-of select="CollapsedDucts"/>
                     <xsl:copy-of select="AbandonedDucts"/>
                     <xsl:copy-of select="OtherDucts"/>
                     <xsl:copy-of select="DuctMaterial"/>
                     <xsl:copy-of select="ProtectiveDevice"/>
                </data:Asset>
                </xsl:if>
            </xsl:for-each>
 
  
        </data:Assets>
    </xsl:template>
</xsl:stylesheet>
