<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:common="urn:epcor:as:Common" xmlns:fn="http://www.w3.org/2005/xpath-functions" exclude-result-prefixes="xsl types xsd bpws xp20 xref orcl ora hwf ids dvm common fn" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
                
  <xsl:param name="processControl"/>
  <xsl:param name="fileName"/>
  <xsl:param name="timestamp"/>
  <xsl:param name="assetTriggerSetStart"/>
                
  <xsl:template match="/data:AssetTriggerSet">
       
  
          <!--xsl:if test="count(data:AssetTriggers/data:AssetTrigger[data:Name='TransStructure' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
            <xsl:variable name="trigger" select="data:AssetTriggers/data:AssetTrigger[data:Name='TransStructure' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
           <xsl:apply-templates select="$trigger">
            <xsl:with-param name="name" select="TransStructure"/>
           </xsl:apply-templates>
          </xsl:if-->

    <data:AssetTriggerStart>
      <xsl:choose>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='TransStructure' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='TransStructure' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Pole' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Pole' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='TransPole' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='TransPole' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Pad' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Pad' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Pedestal' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Pedestal' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='DecorativePole' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='DecorativePole' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='AerialWire' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='AerialWire' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Luminaire' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Luminaire' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Vault' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Vault' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Manhole' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Manhole' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Handhole' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Handhole' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='AerialSwitch' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='AerialSwitch' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Transformer' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Transformer' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when> 
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Cabinet' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Cabinet' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
       <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Conductor' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Conductor' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
        <xsl:when test="count(data:AssetTriggers/data:AssetTrigger[data:Name='Cable' and (not(boolean(string(data:Active))) or data:Active='true')])>0">
          <xsl:copy-of select="data:AssetTriggers/data:AssetTrigger[data:Name='Cable' and (not(boolean(string(data:Active))) or data:Active='true')][1]"/>
        </xsl:when>
      </xsl:choose>
    </data:AssetTriggerStart>
  </xsl:template>
  

  <xsl:template match="/data:AssetTriggerStart">
    <data:AssetTriggerStart>
      <xsl:copy-of select="data:AssetTrigger"/>
      <xsl:choose>
        <xsl:when test="boolean(string($assetTriggerSetStart/data:AssetTriggerSetStart/data:RemoveDelete)) and count(data:AssetTrigger/data:AssetLoads/data:AssetLoad[data:SourceType='delete' and number(data:Number)>100])>0">
          <xsl:copy-of select="$assetTriggerSetStart/data:AssetTriggerSetStart/data:RemoveDelete"/>
        </xsl:when>
        <xsl:otherwise>
          <data:RemoveDelete>false</data:RemoveDelete>
        </xsl:otherwise>
      </xsl:choose>
    </data:AssetTriggerStart>
  </xsl:template>
  
  <xsl:template match="/data:AssetLoads">
    <xsl:variable name="uuid" select="orcl:generate-guid()"/>
    
    <data:AssetTrigger>
 	    <xsl:choose>
        <xsl:when test="starts-with($fileName,'TransStructure')">
        <data:Name>TransStructure</data:Name>
        </xsl:when>
        <xsl:otherwise>
        <data:Name>
                  <xsl:value-of select="$processControl/common:processControl/common:interface"/>
               </data:Name>
        </xsl:otherwise>
      </xsl:choose>
	  
     
      <data:UUID>
        <xsl:value-of select="concat(substring($uuid,1,8),'-',substring($uuid,9,4),'-',substring($uuid,13,4),'-',substring($uuid,17,4),'-',substring($uuid,20,12))"/>
      </data:UUID>
      <data:Active>true</data:Active>
      <data:FileName>
        <xsl:value-of select="$fileName"/>
      </data:FileName>
      <data:CreatedDate>
        <xsl:choose>
          <xsl:when test="not(boolean(normalize-space(string($timestamp)))) or string($timestamp)='null' ">
            <xsl:value-of select="xp20:current-dateTime()"/>
          </xsl:when>
          <xsl:otherwise>
            <xsl:value-of select="fn:adjust-dateTime-to-timezone(xsd:dateTime('1970-01-01T00:00:00Z') + number($timestamp) * xsd:dayTimeDuration('PT0.001S'))"/>
          </xsl:otherwise>
        </xsl:choose>
      </data:CreatedDate>
      <data:ProcessedDate>
        <xsl:value-of select="xp20:current-dateTime()"/>
      </data:ProcessedDate>
      <xsl:copy-of select="."/>
    </data:AssetTrigger>
  </xsl:template>

</xsl:stylesheet>
