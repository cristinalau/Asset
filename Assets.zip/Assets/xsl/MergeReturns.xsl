<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:ehdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.esb.server.headers.ESBHeaderFunctions" xmlns:ivws="urn:epcor:as:ivara:schema:AssetService:1" xmlns:common="urn:epcor:as:Common" exclude-result-prefixes="xsl types tns xsd bpws xp20 xref orcl ora hwf ids ehdr ivws dvm common" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
                
  <xsl:param name="reprocessControl"/>
  <xsl:param name="PoleCallbackVariable.payload"/>
  <xsl:param name="TransPoleCallbackVariable.payload"/>
  <xsl:param name="TransStructureCallbackVariable.payload"/>
  <xsl:param name="CableCallbackVariable.payload"/>
   <xsl:param name="ConductorCallbackVariable.payload"/>
   <xsl:param name="PadCallbackVariable.payload"/>
  <xsl:param name="PedestalCallbackVariable.payload"/>
  <xsl:param name="DecorativePoleCallbackVariable.payload"/>
  <xsl:param name="AerialWireCallbackVariable.payload"/>
  <xsl:param name="LuminaireCallbackVariable.payload"/>
  <xsl:param name="VaultCallbackVariable.payload"/>
  <xsl:param name="ManholeCallbackVariable.payload"/>
  <xsl:param name="HandholeCallbackVariable.payload"/>
  <xsl:param name="AerialSwitchCallbackVariable.payload"/>
  <xsl:param name="TransformerCallbackVariable.payload"/>
  <xsl:param name="CabinetCallbackVariable.payload"/>
  
  <xsl:template match="/data:PoleReturns">
    <data:PoleReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$PoleCallbackVariable.payload/data:PoleReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:PoleReturns>
  </xsl:template>

  <xsl:template match="/data:TransPoleReturns">
    <data:TransPoleReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$TransPoleCallbackVariable.payload/data:TransPoleReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:TransPoleReturns>
  </xsl:template>
  
  <xsl:template match="/data:PadReturns">
    <data:PadReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$PadCallbackVariable.payload/data:PadReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:PadReturns>
  </xsl:template>

  <xsl:template match="/data:PedestalReturns">
    <data:PedestalReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$PedestalCallbackVariable.payload/data:PedestalReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:PedestalReturns>
  </xsl:template>

  <xsl:template match="/data:DecorativePoleReturns">
    <data:DecorativePoleReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$DecorativePoleCallbackVariable.payload/data:DecorativePoleReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:DecorativePoleReturns>
  </xsl:template>

  <xsl:template match="/data:AerialWireReturns">
    <data:AerialWireReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$AerialWireCallbackVariable.payload/data:AerialWireReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:AerialWireReturns>
  </xsl:template>

  <xsl:template match="/data:LuminaireReturns">
    <data:LuminaireReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$LuminaireCallbackVariable.payload/data:LuminaireReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:LuminaireReturns>
  </xsl:template>

  <xsl:template match="/data:VaultReturns">
    <data:VaultReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$VaultCallbackVariable.payload/data:VaultReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:VaultReturns>
  </xsl:template>

  <xsl:template match="/data:ManholeReturns">
    <data:ManholeReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$ManholeCallbackVariable.payload/data:ManholeReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:ManholeReturns>
  </xsl:template>

  <xsl:template match="/data:HandholeReturns">
    <data:HandholeReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$HandholeCallbackVariable.payload/data:HandholeReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:HandholeReturns>
  </xsl:template>

  <xsl:template match="/data:AerialSwitchReturns">
    <data:AerialSwitchReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$AerialSwitchCallbackVariable.payload/data:AerialSwitchReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:AerialSwitchReturns>
  </xsl:template>

  <xsl:template match="/data:TransformerReturns">
    <data:TransformerReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$TransformerCallbackVariable.payload/data:TransformerReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:TransformerReturns>
  </xsl:template>

  <xsl:template match="/data:CabinetReturns">
    <data:CabinetReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$CabinetCallbackVariable.payload/data:CabinetReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:CabinetReturns>
  </xsl:template>

  <xsl:template match="/data:ConductorReturns">
    <data:ConductorReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$ConductorCallbackVariable.payload/data:ConductorReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:ConductorReturns>
  </xsl:template>
  
    <xsl:template match="/data:CableReturns">
    <data:CableReturns>
      <xsl:for-each select="data:Return">
        <xsl:copy-of select="."/>
      </xsl:for-each>
      <xsl:for-each select="$CableCallbackVariable.payload/data:CableReturns/data:Return">
        <xsl:choose>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'all'">
            <xsl:copy-of select="."/>
          </xsl:when>
          <xsl:when test="$reprocessControl/common:reprocessControl/common:status = 'bad'">
            <xsl:if test="./data:ErrorCode != 0">
              <xsl:copy-of select="."/>
            </xsl:if>
          </xsl:when>
          <xsl:otherwise>
          </xsl:otherwise>
        </xsl:choose>
      </xsl:for-each>
    </data:CableReturns>
  </xsl:template>



</xsl:stylesheet>
