<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:ns1="http://schemas.microsoft.com/2003/10/Serialization/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:bpel="http://docs.oasis-open.org/wsbpel/2.0/process/executable" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:wsa10="http://www.w3.org/2005/08/addressing" xmlns:bpm="http://xmlns.oracle.com/bpmn20/extensions" xmlns:soap12="http://schemas.xmlsoap.org/wsdl/soap12/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:mime="http://schemas.xmlsoap.org/wsdl/mime/" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:wsx="http://schemas.xmlsoap.org/ws/2004/09/mex" xmlns:socket="http://www.oracle.com/XSL/Transform/java/oracle.tip.adapter.socket.ProtocolTranslator" xmlns:wsap="http://schemas.xmlsoap.org/ws/2004/08/addressing/policy" xmlns:wsaw="http://www.w3.org/2006/05/addressing/wsdl" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:common="urn:epcor:as:Common" xmlns:mhdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.mediator.service.common.functions.MediatorExtnFunction" xmlns:tns="urn:epcor:as:ivara:ws:AssetService:Mediator" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype" xmlns:med="http://schemas.oracle.com/mediator/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy" xmlns:xdk="http://schemas.oracle.com/bpel/extension/xpath/function/xdk" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:msc="http://schemas.microsoft.com/ws/2005/12/wsdl/contract" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:bpmn="http://schemas.oracle.com/bpm/xpath" xmlns:wsam="http://www.w3.org/2007/05/addressing/metadata" xmlns:ldap="http://schemas.oracle.com/xpath/extension/ldap" exclude-result-prefixes="xsi xsl soap12 soap mime data types tns plnk xsd wsa ns1 wsa10 ns2 soapenc wsdl wsx wsap wsaw wsp msc wsu wsam xp20 bpws bpel bpm ora socket mhdr oraext dvm hwf med ids xdk xref bpmn ldap common">
                
  <xsl:param name="assetActions"/>
  <xsl:param name="processControl"/>
  
  <xsl:key name="lookupSite" match="/data:NotificationGroups/data:NotificationGroup" use="data:Assignee"/>
  <xsl:key name="lookupAssets" match="data:Assets/data:Asset" use="data:Site"/>
  <xsl:key name="lookupDistinct" match="/data:NotificationGroups/data:NotificationGroup/data:Assignee" use="."/>

  <xsl:template match="/data:NotificationGroups">
    <data:AssetsNotificationGroups>
      <xsl:apply-templates select="data:NotificationGroup/data:Assignee"/>
    </data:AssetsNotificationGroups>
  </xsl:template>
  
  <xsl:template match="data:Assignee">
    <xsl:if test="generate-id() = generate-id(key('lookupDistinct',normalize-space(.)))">
      <data:AssetsNotificationGroup>
        <xsl:variable name="group" select="."/>
        <data:Assignee>
          <xsl:value-of select="."/>
        </data:Assignee>
        <data:Assets>
          <xsl:apply-templates select="key('lookupSite',$group)"/>
        </data:Assets>
      </data:AssetsNotificationGroup>
    </xsl:if>
  </xsl:template>
  
  <xsl:template match="data:NotificationGroup">
    <xsl:variable name="site" select="data:Site"/>
    <xsl:for-each select="$assetActions">
      <xsl:for-each select="data:Assets/data:Asset">
        <xsl:if test="data:Site = $site and data:ErrorCode != 0">
          <xsl:copy-of select="."/>
        </xsl:if>
      </xsl:for-each>
    </xsl:for-each>
  </xsl:template>
  
  <xsl:template match="/data:Poles">
    <data:AssetReprocessSet>
      <data:Poles>
        <xsl:for-each select="data:Pole">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Poles>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>
  
  <xsl:template match="/data:TransPoles">
    <data:AssetReprocessSet>
      <data:TransPoles>
        <xsl:for-each select="data:TransPole">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:TransPoles>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>
  
  <xsl:template match="/data:Pads">
    <data:AssetReprocessSet>
      <data:Pads>
        <xsl:for-each select="data:Pad">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Pads>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  <xsl:template match="/data:Pedestals">
    <data:AssetReprocessSet>
      <data:Pedestals>
        <xsl:for-each select="data:Pedestal">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Pedestals>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  <xsl:template match="/data:DecorativePoles">
    <data:AssetReprocessSet>
      <data:DecorativePoles>
        <xsl:for-each select="data:DecorativePole">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:DecorativePoles>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  <xsl:template match="/data:AerialWires">
    <data:AssetReprocessSet>
      <data:AerialWires>
        <xsl:for-each select="data:AerialWire">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:AerialWires>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  <xsl:template match="/data:Luminaires">
    <data:AssetReprocessSet>
      <data:Luminaires>
        <xsl:for-each select="data:Luminaire">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Luminaires>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  <xsl:template match="/data:Vaults">
    <data:AssetReprocessSet>
      <data:Vaults>
        <xsl:for-each select="data:Vault">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Vaults>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  <xsl:template match="/data:Manholes">
    <data:AssetReprocessSet>
      <data:Manholes>
        <xsl:for-each select="data:Manhole">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Manholes>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  <xsl:template match="/data:Handholes">
    <data:AssetReprocessSet>
      <data:Handholes>
        <xsl:for-each select="data:Handhole">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Handholes>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  <xsl:template match="/data:AerialSwitches">
    <data:AssetReprocessSet>
      <data:AerialSwitches>
        <xsl:for-each select="data:AerialSwitch">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:AerialSwitches>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>
  
  <xsl:template match="/data:Transformers">
    <data:AssetReprocessSet>
      <data:Transformers>
        <xsl:for-each select="data:Transformer">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Transformers>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  <xsl:template match="/data:Cabinets">
    <data:AssetReprocessSet>
      <data:Cabinets>
        <xsl:for-each select="data:Cabinet">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Cabinets>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>
 <xsl:template match="/data:Conductors">
    <data:AssetReprocessSet>
      <data:Conductors>
        <xsl:for-each select="data:Conductor">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Conductors>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>
  <xsl:template match="/data:Cables">
    <data:AssetReprocessSet>
      <data:Cables>
        <xsl:for-each select="data:Cable">
          <xsl:if test="data:ErrorCode=-1 or boolean(string(data:ErrorText))">
            <xsl:copy-of select="."/>
          </xsl:if>
        </xsl:for-each>
      </data:Cables>
      <data:Session>
        <xsl:value-of select="$processControl/common:processControl/common:session"/>
      </data:Session>
    </data:AssetReprocessSet>
  </xsl:template>

  </xsl:stylesheet>
