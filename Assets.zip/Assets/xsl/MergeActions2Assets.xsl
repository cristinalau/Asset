<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:ehdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.esb.server.headers.ESBHeaderFunctions" xmlns:ebs="http://xmlns.oracle.com/pcbpel/adapter/db/EBSPoles" xmlns:common="urn:epcor:as:Common" exclude-result-prefixes="xsl types xsd bpws xp20 xref orcl ora hwf ids ehdr ebs xsi dvm" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
                
   <xsl:param name="assetsNotificationGroup"/>
   
   <xsl:key name="actionLookup" match="data:AssetsNotificationGroup/data:Assets/data:Asset" use="data:UUID"/>
   
   <xsl:template match="/data:AssetReprocessSet">
      <data:AssetReprocessSet>
         <data:Poles>
         <xsl:for-each select="data:Poles/data:Pole">
            <xsl:variable name="uuid" select="data:UUID"/>
            <xsl:variable name="reprocess">
              <xsl:for-each select="$assetsNotificationGroup">
                <xsl:choose>
                  <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                  <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
              </xsl:for-each>
            </xsl:variable>
            
            <data:Pole>
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:copy-of select="data:UUID"/>
               <xsl:copy-of select="data:ID"/>
               <xsl:copy-of select="data:AssetType"/>
               <xsl:copy-of select="data:OwnerType"/>
               <xsl:copy-of select="data:OwnerName"/>
               <xsl:copy-of select="data:GeoLocation"/>
               <xsl:copy-of select="data:StartDate"/>
               <xsl:copy-of select="data:Circuits"/>
               <xsl:copy-of select="data:SourceStatus"/>
               <xsl:copy-of select="data:SourceType"/>
               <xsl:copy-of select="data:PreviousAsset"/>

               <xsl:copy-of select="data:ProcessedDate"/>
               <xsl:copy-of select="data:IvaraOI"/>
               <xsl:copy-of select="data:CreatedDate"/>
               <xsl:copy-of select="data:ErrorCode"/>
               <xsl:copy-of select="data:ErrorText"/>

               <xsl:choose>
                  <xsl:when test="string($reprocess) = 'true'">
                     <xsl:for-each select="$assetsNotificationGroup">
                        <data:Comment>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                        </data:Comment>
                        <data:Action>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                        </data:Action>
                     </xsl:for-each>
                  </xsl:when>
                  <xsl:otherwise>
                     <xsl:copy-of select="data:Comment"/>
                     <xsl:copy-of select="data:Action"/>
                  </xsl:otherwise>
               </xsl:choose>
               <xsl:copy-of select="data:Site"/>
               
               <xsl:copy-of select="data:Height"/>
               <xsl:copy-of select="data:FrameType"/>
               <xsl:copy-of select="data:Class"/>
               <xsl:copy-of select="data:Usage"/>
               <xsl:copy-of select="data:Material"/>
               <xsl:copy-of select="data:Treatment"/>
               <xsl:copy-of select="data:Remark"/>
               <xsl:copy-of select="data:ReinforcementType"/>
               <xsl:copy-of select="data:DeadEndIndicator"/>
               <xsl:copy-of select="data:Phases"/>
               <xsl:copy-of select="data:FiberOptics"/>
               <xsl:copy-of select="data:WorkOrderNumber"/>
               <xsl:copy-of select="data:TotalForeignAttachments"/>
               <xsl:copy-of select="data:Transformers"/>
               <xsl:copy-of select="data:Grouping"/>
               <xsl:copy-of select="data:AerialSwitches"/>
            </data:Pole>
         </xsl:for-each>
         </data:Poles>
        <data:TransPoles>
         <xsl:for-each select="data:TransPoles/data:TransPole">
            <xsl:variable name="uuid" select="data:UUID"/>
            <xsl:variable name="reprocess">
              <xsl:for-each select="$assetsNotificationGroup">
                <xsl:choose>
                  <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                  <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
              </xsl:for-each>
            </xsl:variable>
            
            <data:TransPole>
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:copy-of select="data:UUID"/>
               <xsl:copy-of select="data:ID"/>
               <xsl:copy-of select="data:AssetType"/>
               <xsl:copy-of select="data:OwnerType"/>
               <xsl:copy-of select="data:OwnerName"/>
               <xsl:copy-of select="data:GeoLocation"/>
               <xsl:copy-of select="data:StartDate"/>
               <xsl:copy-of select="data:Circuits"/>
               <xsl:copy-of select="data:SourceStatus"/>
               <xsl:copy-of select="data:SourceType"/>
               <xsl:copy-of select="data:MultiFamily" />
               <xsl:copy-of select="data:PreviousAsset"/>

               <xsl:copy-of select="data:ProcessedDate"/>
               <xsl:copy-of select="data:IvaraOI"/>
               <xsl:copy-of select="data:CreatedDate"/>
               <xsl:copy-of select="data:ErrorCode"/>
               <xsl:copy-of select="data:ErrorText"/>

               <xsl:choose>
                  <xsl:when test="string($reprocess) = 'true'">
                     <xsl:for-each select="$assetsNotificationGroup">
                        <data:Comment>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                        </data:Comment>
                        <data:Action>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                        </data:Action>
                     </xsl:for-each>
                  </xsl:when>
                  <xsl:otherwise>
                     <xsl:copy-of select="data:Comment"/>
                     <xsl:copy-of select="data:Action"/>
                  </xsl:otherwise>
               </xsl:choose>
               <xsl:copy-of select="data:Site"/>
               
               <xsl:copy-of select="data:Height"/>
               <xsl:copy-of select="data:FrameType"/>
               <xsl:copy-of select="data:Class"/>
               <xsl:copy-of select="data:Usage"/>
               <xsl:copy-of select="data:Material"/>
               <xsl:copy-of select="data:Treatment"/>
               <xsl:copy-of select="data:Remark"/>
               <xsl:copy-of select="data:ReinforcementType"/>
               <xsl:copy-of select="data:DeadEndIndicator"/>
               <xsl:copy-of select="data:Phases"/>
               <xsl:copy-of select="data:FiberOptics"/>
               <xsl:copy-of select="data:WorkOrderNumber"/>
               <xsl:copy-of select="data:TotalForeignAttachments"/>
               <xsl:copy-of select="data:Transformers"/>
               <xsl:copy-of select="data:Grouping"/>
               <xsl:copy-of select="data:AerialSwitches"/>
				<xsl:copy-of select="data:Configuration"/>
				<xsl:copy-of select="data:DateInstalled"/>
           </data:TransPole>
         </xsl:for-each>
         </data:TransPoles>
        <data:TransStructures>
         <xsl:for-each select="data:TransStructures/data:TransStructure">
            <xsl:variable name="uuid" select="data:UUID"/>
            <xsl:variable name="reprocess">
              <xsl:for-each select="$assetsNotificationGroup">
                <xsl:choose>
                  <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                  <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
              </xsl:for-each>
            </xsl:variable>
            
            <data:TransStructure>
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:copy-of select="data:UUID"/>
               <xsl:copy-of select="data:ID"/>
               <xsl:copy-of select="data:AssetType"/>
               <xsl:copy-of select="data:OwnerType"/>
               <xsl:copy-of select="data:OwnerName"/>
               <xsl:copy-of select="data:GeoLocation"/>
               <xsl:copy-of select="data:StartDate"/>
               <xsl:copy-of select="data:Circuits"/>
               <xsl:copy-of select="data:SourceStatus"/>
               <xsl:copy-of select="data:SourceType"/>
               <xsl:copy-of select="data:MultiFamily" />
               <xsl:copy-of select="data:PreviousAsset"/>

               <xsl:copy-of select="data:ProcessedDate"/>
               <xsl:copy-of select="data:IvaraOI"/>
               <xsl:copy-of select="data:CreatedDate"/>
               <xsl:copy-of select="data:ErrorCode"/>
               <xsl:copy-of select="data:ErrorText"/>

               <xsl:choose>
                  <xsl:when test="string($reprocess) = 'true'">
                     <xsl:for-each select="$assetsNotificationGroup">
                        <data:Comment>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                        </data:Comment>
                        <data:Action>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                        </data:Action>
                     </xsl:for-each>
                  </xsl:when>
                  <xsl:otherwise>
                     <xsl:copy-of select="data:Comment"/>
                     <xsl:copy-of select="data:Action"/>
                  </xsl:otherwise>
               </xsl:choose>
               <xsl:copy-of select="data:Site"/>
               
               <xsl:copy-of select="data:Height"/>
               <xsl:copy-of select="data:FrameType"/>
               <xsl:copy-of select="data:Class"/>
               <xsl:copy-of select="data:Usage"/>
               <xsl:copy-of select="data:Material"/>
               <xsl:copy-of select="data:Treatment"/>
               <xsl:copy-of select="data:Remark"/>
               <xsl:copy-of select="data:ReinforcementType"/>
               <xsl:copy-of select="data:DeadEndIndicator"/>
               <xsl:copy-of select="data:Phases"/>
               <xsl:copy-of select="data:FiberOptics"/>
               <xsl:copy-of select="data:WorkOrderNumber"/>
               <xsl:copy-of select="data:TotalForeignAttachments"/>
               <xsl:copy-of select="data:Transformers"/>
               <xsl:copy-of select="data:Grouping"/>
               <xsl:copy-of select="data:AerialSwitches"/>
				<xsl:copy-of select="data:Configuration"/>
				<xsl:copy-of select="data:DateInstalled"/>
           </data:TransStructure>
         </xsl:for-each>
         </data:TransStructures>
         <data:Cables>
         <xsl:for-each select="data:Cables/data:Cable">
            <xsl:variable name="uuid" select="data:UUID"/>
            <xsl:variable name="reprocess">
              <xsl:for-each select="$assetsNotificationGroup">
                <xsl:choose>
                  <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                  <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
              </xsl:for-each>
            </xsl:variable>
            
            <data:Cable>
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:copy-of select="data:UUID"/>
               <xsl:copy-of select="data:ID"/>
               <xsl:copy-of select="data:AssetType"/>
               <xsl:copy-of select="data:OwnerType"/>
               <xsl:copy-of select="data:OwnerName"/>
               <xsl:copy-of select="data:GeoLocation"/>
               <xsl:copy-of select="data:StartDate"/>
               <xsl:copy-of select="data:Circuits"/>
               <xsl:copy-of select="data:SourceStatus"/>
               <xsl:copy-of select="data:SourceType"/>
               <xsl:copy-of select="data:MultiFamily" />
               <xsl:copy-of select="data:PreviousAsset"/>

               <xsl:copy-of select="data:ProcessedDate"/>
               <xsl:copy-of select="data:IvaraOI"/>
               <xsl:copy-of select="data:CreatedDate"/>
               <xsl:copy-of select="data:ErrorCode"/>
               <xsl:copy-of select="data:ErrorText"/>

               <xsl:choose>
                  <xsl:when test="string($reprocess) = 'true'">
                     <xsl:for-each select="$assetsNotificationGroup">
                        <data:Comment>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                        </data:Comment>
                        <data:Action>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                        </data:Action>
                     </xsl:for-each>
                  </xsl:when>
                  <xsl:otherwise>
                     <xsl:copy-of select="data:Comment"/>
                     <xsl:copy-of select="data:Action"/>
                  </xsl:otherwise>
               </xsl:choose>
               <xsl:copy-of select="data:Site"/>
    			   
                <xsl:copy-of select="Insulation"/>
                <xsl:copy-of select="Arrangement"/>
                <xsl:copy-of select="CalculatedLength"/>
                <xsl:copy-of select="EpcInjectable"/>
                <xsl:copy-of select="EpcInjectedDate"/>
                <xsl:copy-of select="EpcInjectionMethod"/>
                <xsl:copy-of select="NeutralConfiguration"/>
                <xsl:copy-of select="NominalVoltage"/>
                <xsl:copy-of select="OutsideDiameter"/>
                <xsl:copy-of select="RatedVoltage"/>
                <xsl:copy-of select="RepairSplices"/>
                <xsl:copy-of select="Size"/>
                <xsl:copy-of select="Splices"/>
                <xsl:copy-of select="AvailableDucts"/>
                <xsl:copy-of select="UsedDucts"/>
                <xsl:copy-of select="CollapsedDucts"/>
                <xsl:copy-of select="AbandonedDucts"/>
                <xsl:copy-of select="OtherDucts"/>
                <xsl:copy-of select="DuctMaterial"/>

                <xsl:copy-of select="ProtectiveDevice"/>

	   
            </data:Cable>
         </xsl:for-each>
         </data:Cables>
        <data:Conductors>
         <xsl:for-each select="data:Conductors/data:Conductor">
            <xsl:variable name="uuid" select="data:UUID"/>
            <xsl:variable name="reprocess">
              <xsl:for-each select="$assetsNotificationGroup">
                <xsl:choose>
                  <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                  <xsl:otherwise>false</xsl:otherwise>
                </xsl:choose>
              </xsl:for-each>
            </xsl:variable>
            
            <data:Conductor>
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:copy-of select="data:UUID"/>
               <xsl:copy-of select="data:ID"/>
               <xsl:copy-of select="data:AssetType"/>
               <xsl:copy-of select="data:OwnerType"/>
               <xsl:copy-of select="data:OwnerName"/>
               <xsl:copy-of select="data:GeoLocation"/>
               <xsl:copy-of select="data:StartDate"/>
               <xsl:copy-of select="data:Circuits"/>
               <xsl:copy-of select="data:SourceStatus"/>
               <xsl:copy-of select="data:SourceType"/>
               <xsl:copy-of select="data:MultiFamily" />
               <xsl:copy-of select="data:PreviousAsset"/>

               <xsl:copy-of select="data:ProcessedDate"/>
               <xsl:copy-of select="data:IvaraOI"/>
               <xsl:copy-of select="data:CreatedDate"/>
               <xsl:copy-of select="data:ErrorCode"/>
               <xsl:copy-of select="data:ErrorText"/>

               <xsl:choose>
                  <xsl:when test="string($reprocess) = 'true'">
                     <xsl:for-each select="$assetsNotificationGroup">
                        <data:Comment>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                        </data:Comment>
                        <data:Action>
                           <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                        </data:Action>
                     </xsl:for-each>
                  </xsl:when>
                  <xsl:otherwise>
                     <xsl:copy-of select="data:Comment"/>
                     <xsl:copy-of select="data:Action"/>
                  </xsl:otherwise>
               </xsl:choose>
               <xsl:copy-of select="data:Site"/>
    			   
                <xsl:copy-of select="Insulation"/>
                <xsl:copy-of select="Arrangement"/>
                <xsl:copy-of select="CalculatedLength"/>
                <xsl:copy-of select="EpcInjectable"/>
                <xsl:copy-of select="EpcInjectedDate"/>
                <xsl:copy-of select="EpcInjectionMethod"/>
                <xsl:copy-of select="NeutralConfiguration"/>
                <xsl:copy-of select="NominalVoltage"/>
                <xsl:copy-of select="OutsideDiameter"/>
                <xsl:copy-of select="RatedVoltage"/>
                <xsl:copy-of select="RepairSplices"/>
                <xsl:copy-of select="Size"/>
                <xsl:copy-of select="Splices"/>
                <xsl:copy-of select="AvailableDucts"/>
                <xsl:copy-of select="UsedDucts"/>
                <xsl:copy-of select="CollapsedDucts"/>
                <xsl:copy-of select="AbandonedDucts"/>
                <xsl:copy-of select="OtherDucts"/>
                <xsl:copy-of select="DuctMaterial"/>
                <xsl:copy-of select="ProtectiveDevice"/>

	   
            </data:Conductor>
         </xsl:for-each>
         </data:Conductors>

         <data:Pads>
            <xsl:for-each select="data:Pads/data:Pad">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>
               <data:Pad>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily" />
                  <xsl:copy-of select="data:PreviousAsset"/>
                  
                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>
                  
                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>
                  <xsl:copy-of select="data:Site"/>
                  
                  <xsl:copy-of select="data:FiberOptics"/>
                  <xsl:copy-of select="data:WorkOrderNumber"/>
                  <xsl:copy-of select="data:Transformers"/>
                  <xsl:copy-of select="data:Cabinets"/>
               </data:Pad>
            </xsl:for-each>
         </data:Pads>
         <data:Pedestals>
            <xsl:for-each select="data:Pedestals/data:Pedestal">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>
               <data:Pedestal>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily" />
                  <xsl:copy-of select="data:PreviousAsset"/>

                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>

                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>
                  <xsl:copy-of select="data:Site"/>

                  <xsl:copy-of select="data:FiberOptics"/>
                  <xsl:copy-of select="data:WorkOrderNumber"/>
                  <xsl:copy-of select="data:Transformers"/>
               </data:Pedestal>
            </xsl:for-each>
         </data:Pedestals>

         <data:DecorativePoles>
            <xsl:for-each select="data:DecorativePoles/data:DecorativePole">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>
               <data:DecorativePole>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily"/>
                  <xsl:copy-of select="data:PreviousAsset"/>

                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>

                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>

                  <xsl:copy-of select="data:PoleHeight" />
                  <xsl:copy-of select="data:DecorativePoleType" />
                  <xsl:copy-of select="data:Material" />
                  <xsl:copy-of select="data:TotalForeignAttachments" />
                  <xsl:copy-of select="data:Phasing" />
                  <xsl:copy-of select="data:SiteId" />
                  <xsl:copy-of select="data:SiteEnergizeStatus" />
                  <xsl:copy-of select="data:SiteAddress" />
                  <xsl:copy-of select="data:Luminaires" />
               </data:DecorativePole>
            </xsl:for-each>
         </data:DecorativePoles>

         <data:AerialWires>
            <xsl:for-each select="data:AerialWires/data:AerialWire">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>
               <data:AerialWire>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily"/>
                  <xsl:copy-of select="data:PreviousAsset"/>

                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>

                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>

                  <!-- TODO:  Aerial Wire -->
               </data:AerialWire>
            </xsl:for-each>
         </data:AerialWires>

         <data:Luminaires>
            <xsl:for-each select="data:Luminaires/data:Luminaire">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>
               <data:Luminaire>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily"/>
                  <xsl:copy-of select="data:PreviousAsset"/>

                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>

                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>

                  <xsl:copy-of select="data:Manufacturer"/>
                  <xsl:copy-of select="data:ControlType" />
                  <xsl:copy-of select="data:LampType" />
                  <xsl:copy-of select="data:NominalVoltagePP" />
                  <xsl:copy-of select="data:NominalVoltagePN" />
                  <xsl:copy-of select="data:PowerConsumption" />
                  <xsl:copy-of select="data:LightLumens" />
                  <xsl:copy-of select="data:SiteId"/>
                  <xsl:copy-of select="data:SiteEnergizeStatus"/>
                  <xsl:copy-of select="data:SiteAddress"/>
                  <xsl:copy-of select="data:Poles" />
                  <xsl:copy-of select="data:DecorativePoles" />
               </data:Luminaire>
            </xsl:for-each>
         </data:Luminaires>

         <data:Vaults>
            <xsl:for-each select="data:Vaults/data:Vault">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>
               <data:Vault>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily" />
                  <xsl:copy-of select="data:PreviousAsset"/>
                  
                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>
                  
                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>
                  <xsl:copy-of select="data:Site"/>
                  
                  <xsl:copy-of select="data:FiberOptics"/>
                  <xsl:copy-of select="data:VaultType"/>
                  <xsl:copy-of select="data:WorkOrderNumber"/>
                  <xsl:copy-of select="data:Transformers"/>
                  <xsl:copy-of select="data:Cabinets"/>
               </data:Vault>
            </xsl:for-each>
         </data:Vaults>
         <data:Manholes>
            <xsl:for-each select="data:Manholes/data:Manhole">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>

               <data:Manhole>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily" />
                  <xsl:copy-of select="data:PreviousAsset"/>

                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>

                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>
                  <xsl:copy-of select="data:Site"/>
                  <xsl:copy-of select="data:ManholeType"/>
                  <xsl:copy-of select="data:Usage"/>
                  <xsl:copy-of select="data:WorkOrderNumber"/>
               </data:Manhole>
            </xsl:for-each>
         </data:Manholes>
         <data:Handholes>
            <xsl:for-each select="data:Handholes/data:Handhole">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>

               <data:Handhole>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily" />
                  <xsl:copy-of select="data:PreviousAsset"/>

                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>

                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>
                  <xsl:copy-of select="data:Site"/>
                  <xsl:copy-of select="data:HandholeType"/>
                  <xsl:copy-of select="data:Usage"/>
                  <xsl:copy-of select="data:WorkOrderNumber"/>
               </data:Handhole>
            </xsl:for-each>
         </data:Handholes>
         <data:AerialSwitches>
             <xsl:for-each select="data:AerialSwitches/data:AerialSwitch">
                <xsl:variable name="uuid" select="data:UUID"/>
                <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                    <xsl:choose>
                      <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                      <xsl:otherwise>false</xsl:otherwise>
                    </xsl:choose>
                  </xsl:for-each>
                </xsl:variable>
                
                <data:AerialSwitch>
                   <xsl:variable name="uuid" select="data:UUID"/>
                   <xsl:copy-of select="data:UUID"/>
                   <xsl:copy-of select="data:ID"/>
                   <xsl:copy-of select="data:AssetType"/>
                   <xsl:copy-of select="data:OwnerType"/>
                   <xsl:copy-of select="data:OwnerName"/>
                   <xsl:copy-of select="data:GeoLocation"/>
                   <xsl:copy-of select="data:StartDate"/>
                   <xsl:copy-of select="data:Circuits"/>
                   <xsl:copy-of select="data:SourceStatus"/>
                   <xsl:copy-of select="data:SourceType"/>
                   <xsl:copy-of select="data:MultiFamily" />
                   <xsl:copy-of select="data:PreviousAsset"/>
    
                   <xsl:copy-of select="data:ProcessedDate"/>
                   <xsl:copy-of select="data:IvaraOI"/>
                   <xsl:copy-of select="data:CreatedDate"/>
                   <xsl:copy-of select="data:ErrorCode"/>
                   <xsl:copy-of select="data:ErrorText"/>
    
                   <xsl:choose>
                      <xsl:when test="string($reprocess) = 'true'">
                         <xsl:for-each select="$assetsNotificationGroup">
                            <data:Comment>
                               <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                            </data:Comment>
                            <data:Action>
                               <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                            </data:Action>
                         </xsl:for-each>
                      </xsl:when>
                      <xsl:otherwise>
                         <xsl:copy-of select="data:Comment"/>
                         <xsl:copy-of select="data:Action"/>
                      </xsl:otherwise>
                   </xsl:choose>
                   <xsl:copy-of select="data:Site"/>
                   
                  <xsl:copy-of select="data:AerialSwitchType"/>
                  <xsl:copy-of select="data:NormalStatus"/>
                  <xsl:copy-of select="data:Phasing"/>
                  <xsl:copy-of select="data:Mounting"/>
                  <xsl:copy-of select="data:VoltageRating"/>
                  <xsl:copy-of select="data:ContinuousAmpRating"/>
                  <xsl:copy-of select="data:FuseUnits"/>
                  <xsl:copy-of select="data:SwitchUnits"/>
                  <xsl:copy-of select="data:SwitchSize"/>
                  <xsl:copy-of select="data:LoadBreak"/>
                  <xsl:copy-of select="data:VendorName"/>
                  <xsl:copy-of select="data:WorkOrderNumber"/>
                  <xsl:copy-of select="data:Poles"/>
                  <xsl:copy-of select="data:CircuitTieIndicator"/>
                  <xsl:copy-of select="data:Grouping"/>
                </data:AerialSwitch>
             </xsl:for-each>
         </data:AerialSwitches>
         <data:Transformers>
            <xsl:for-each select="data:Transformers/data:Transformer">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>
               <data:Transformer>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily" />
                  <xsl:copy-of select="data:PreviousAsset"/>
                  
                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>
                  
                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>
                  <xsl:copy-of select="data:Site"/>
                  
                  <xsl:copy-of select="data:Category"/>
                  <xsl:copy-of select="data:BankConfiguration"/>
                  <xsl:copy-of select="data:ServiceIPPIndicator"/>
                  <xsl:copy-of select="data:SpecialLoading"/>
                  <xsl:copy-of select="data:TransformerType"/>
                  <xsl:copy-of select="data:DemandPoints"/>
                  <xsl:copy-of select="data:WorkOrderNumber"/>
                  <xsl:copy-of select="data:Poles"/>
                  <xsl:copy-of select="data:Pads"/>
                  <xsl:copy-of select="data:Pedestals"/>
                  <xsl:copy-of select="data:DecorativePoles"/>
                  <xsl:copy-of select="data:Luminaires"/>
                  <xsl:copy-of select="data:Vaults"/>
               </data:Transformer>
            </xsl:for-each>
         </data:Transformers>
         <data:Cabinets>
            <xsl:for-each select="data:Cabinets/data:Cabinet">
               <xsl:variable name="uuid" select="data:UUID"/>
               <xsl:variable name="reprocess">
                  <xsl:for-each select="$assetsNotificationGroup">
                     <xsl:choose>
                        <xsl:when test="count(key('actionLookup',$uuid)) > 0">true</xsl:when>
                        <xsl:otherwise>false</xsl:otherwise>
                     </xsl:choose>
                  </xsl:for-each>
               </xsl:variable>
               <data:Cabinet>
                  <xsl:variable name="uuid" select="data:UUID"/>
                  <xsl:copy-of select="data:UUID"/>
                  <xsl:copy-of select="data:ID"/>
                  <xsl:copy-of select="data:AssetType"/>
                  <xsl:copy-of select="data:OwnerType"/>
                  <xsl:copy-of select="data:OwnerName"/>
                  <xsl:copy-of select="data:GeoLocation"/>
                  <xsl:copy-of select="data:StartDate"/>
                  <xsl:copy-of select="data:Circuits"/>
                  <xsl:copy-of select="data:SourceStatus"/>
                  <xsl:copy-of select="data:SourceType"/>
                  <xsl:copy-of select="data:MultiFamily" />
                  <xsl:copy-of select="data:PreviousAsset"/>
                  
                  <xsl:copy-of select="data:ProcessedDate"/>
                  <xsl:copy-of select="data:IvaraOI"/>
                  <xsl:copy-of select="data:CreatedDate"/>
                  <xsl:copy-of select="data:ErrorCode"/>
                  <xsl:copy-of select="data:ErrorText"/>
                  
                  <xsl:choose>
                     <xsl:when test="string($reprocess) = 'true'">
                        <xsl:for-each select="$assetsNotificationGroup">
                           <data:Comment>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Comment"/>
                           </data:Comment>
                           <data:Action>
                              <xsl:value-of select="key('actionLookup',$uuid)[1]/data:Action"/>
                           </data:Action>
                        </xsl:for-each>
                     </xsl:when>
                     <xsl:otherwise>
                        <xsl:copy-of select="data:Comment"/>
                        <xsl:copy-of select="data:Action"/>
                     </xsl:otherwise>
                  </xsl:choose>
                  <xsl:copy-of select="data:Site"/>
                  
                  <xsl:copy-of select="data:LiveFrontIndicator"/>
                  <xsl:copy-of select="data:CabinetType"/>
                  <xsl:copy-of select="data:WorkOrderNumber"/>
                  <xsl:copy-of select="data:Pads"/>
                  <xsl:copy-of select="data:Pedestals"/>
                  <xsl:copy-of select="data:DecorativePoles"/>
                  <xsl:copy-of select="data:Luminaires"/>
               </data:Cabinet>
            </xsl:for-each>
         </data:Cabinets>
      </data:AssetReprocessSet>
   </xsl:template>
   
</xsl:stylesheet>
