<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orcl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:ehdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.esb.server.headers.ESBHeaderFunctions" xmlns:ebs="http://xmlns.oracle.com/pcbpel/adapter/db/EBSPoles" xmlns:common="urn:epcor:as:Common" exclude-result-prefixes="xsl types xsd bpws xp20 xref orcl ora hwf ids ehdr ebs xsi dvm" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue">
                
   <xsl:template match="/data:Poles">
      <data:Poles>
         <xsl:apply-templates select="data:Pole"/>
      </data:Poles>
   </xsl:template>
   <xsl:template match="/data:Cables">
      <data:Cables>
         <xsl:apply-templates select="data:Cable"/>
      </data:Cables>
   </xsl:template>
    <xsl:template match="/data:Conductors">
      <data:Conductors>
         <xsl:apply-templates select="data:Conductor"/>
      </data:Conductors>
   </xsl:template>  
   <xsl:template match="data:Pole">
      <data:Pole>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>
         
         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>
         
         <xsl:copy-of select="data:Height"/>
         <xsl:copy-of select="data:FrameType"/>
         <xsl:copy-of select="data:Class"/>
         <xsl:copy-of select="data:Usage"/>
         <xsl:copy-of select="data:Guys"/>
         <xsl:copy-of select="data:Risers"/>
         <xsl:copy-of select="data:Material"/>
         <xsl:copy-of select="data:Treatment"/>
         <xsl:copy-of select="data:Remark"/>
         <xsl:copy-of select="data:ReinforcementType"/>
         <xsl:copy-of select="data:DeadEndIndicator"/>
         <xsl:copy-of select="data:Phases"/>
         <xsl:copy-of select="data:FiberOptics"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
         <xsl:copy-of select="data:TotalForeignAttachments"/>
         <xsl:copy-of select="data:Transformers"/>
         <xsl:copy-of select="data:Grouping"/>
         <xsl:copy-of select="data:AerialSwitches"/>
      </data:Pole>
   </xsl:template>
 
    <xsl:template match="data:TransPole">
      <data:TransPole>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>
         
         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>
         
         <xsl:copy-of select="data:Height"/>
         <xsl:copy-of select="data:FrameType"/>
         <xsl:copy-of select="data:Class"/>
         <xsl:copy-of select="data:Usage"/>
         <xsl:copy-of select="data:Guys"/>
         <xsl:copy-of select="data:Risers"/>
         <xsl:copy-of select="data:Material"/>
         <xsl:copy-of select="data:Treatment"/>
         <xsl:copy-of select="data:Remark"/>
         <xsl:copy-of select="data:ReinforcementType"/>
         <xsl:copy-of select="data:DeadEndIndicator"/>
         <xsl:copy-of select="data:Phases"/>
         <xsl:copy-of select="data:FiberOptics"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
         <xsl:copy-of select="data:TotalForeignAttachments"/>
         <xsl:copy-of select="data:Transformers"/>
         <xsl:copy-of select="data:Grouping"/>
         <xsl:copy-of select="data:AerialSwitches"/>
        <xsl:copy-of select="data:Configuration"/>
        <xsl:copy-of select="data:DateInstalled"/>
 
 </data:TransPole>
   </xsl:template>
   
    <xsl:template match="data:TransStructure">
      <data:TransStructure>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>
         
         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>
         
         <xsl:copy-of select="data:Height"/>
         <xsl:copy-of select="data:FrameType"/>
         <xsl:copy-of select="data:Class"/>
         <xsl:copy-of select="data:Usage"/>
         <xsl:copy-of select="data:Guys"/>
         <xsl:copy-of select="data:Risers"/>
         <xsl:copy-of select="data:Material"/>
         <xsl:copy-of select="data:Treatment"/>
         <xsl:copy-of select="data:Remark"/>
         <xsl:copy-of select="data:ReinforcementType"/>
         <xsl:copy-of select="data:DeadEndIndicator"/>
         <xsl:copy-of select="data:Phases"/>
         <xsl:copy-of select="data:FiberOptics"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
         <xsl:copy-of select="data:TotalForeignAttachments"/>
         <xsl:copy-of select="data:Transformers"/>
         <xsl:copy-of select="data:Grouping"/>
         <xsl:copy-of select="data:AerialSwitches"/>
        <xsl:copy-of select="data:Configuration"/>
        <xsl:copy-of select="data:DateInstalled"/>
 
 </data:TransStructure>
   </xsl:template>  
   
  <xsl:template match="data:Cable">
      <data:Cable>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>
         
         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>
         
         <xsl:copy-of select="data:Site"/>    			   
         <xsl:copy-of select="Insulation"/>
         <xsl:copy-of select="Arrangement"/>
         <xsl:copy-of select="CalculatedLength"/>
         <xsl:copy-of select="EpcInjectable"/>
         <xsl:copy-of select="EpcInjectedDate"/>
         <xsl:copy-of select="EpcInjectionMethod"/>
         <xsl:copy-of select="NeutralConfiguration"/>
         <xsl:copy-of select="NominalVoltage"/>
         <xsl:copy-of select="OutsideDiameter"/>
         <xsl:copy-of select="RatedVoltage"/>
         <xsl:copy-of select="RepairSplices"/>
         <xsl:copy-of select="Size"/>
         <xsl:copy-of select="Splices"/>
         <xsl:copy-of select="AvailableDucts"/>
         <xsl:copy-of select="UsedDucts"/>
         <xsl:copy-of select="CollapsedDucts"/>
         <xsl:copy-of select="AbandonedDucts"/>
         <xsl:copy-of select="OtherDucts"/>
         <xsl:copy-of select="DuctMaterial"/>
         <xsl:copy-of select="ProtectiveDevice"/>
      </data:Cable>
   </xsl:template>

  <xsl:template match="data:Conductor">
      <data:Conductor>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>
         
         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>
         
         <xsl:copy-of select="data:Site"/>
    			   
         <xsl:copy-of select="Insulation"/>
         <xsl:copy-of select="Arrangement"/>
         <xsl:copy-of select="CalculatedLength"/>
         <xsl:copy-of select="EpcInjectable"/>
         <xsl:copy-of select="EpcInjectedDate"/>
         <xsl:copy-of select="EpcInjectionMethod"/>
         <xsl:copy-of select="NeutralConfiguration"/>
         <xsl:copy-of select="NominalVoltage"/>
         <xsl:copy-of select="OutsideDiameter"/>
         <xsl:copy-of select="RatedVoltage"/>
         <xsl:copy-of select="RepairSplices"/>
         <xsl:copy-of select="Size"/>
         <xsl:copy-of select="Splices"/>
         <xsl:copy-of select="AvailableDucts"/>
         <xsl:copy-of select="UsedDucts"/>
         <xsl:copy-of select="CollapsedDucts"/>
         <xsl:copy-of select="AbandonedDucts"/>
         <xsl:copy-of select="OtherDucts"/>
         <xsl:copy-of select="DuctMaterial"/>
         <xsl:copy-of select="ProtectiveDevice"/>
      </data:Conductor>
   </xsl:template>

   
   <xsl:template match="/data:Pads">
      <data:Pads>
         <xsl:apply-templates select="data:Pad"/>
      </data:Pads>
   </xsl:template>
   
   <xsl:template match="data:Pad">
      <data:Pad>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <xsl:copy-of select="data:FiberOptics"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
         <xsl:copy-of select="data:Transformers"/>
         <xsl:copy-of select="data:Cabinets"/>
      </data:Pad>
   </xsl:template>


   <xsl:template match="/data:Pedestals">
      <data:Pedestals>
         <xsl:apply-templates select="data:Pedestal"/>
      </data:Pedestals>
   </xsl:template>

   <xsl:template match="data:Pedestal">
      <data:Pedestal>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <xsl:copy-of select="data:FiberOptics"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
         <xsl:copy-of select="data:Transformers"/>
         <xsl:copy-of select="data:Cabinets"/>
      </data:Pedestal>
   </xsl:template>


   <xsl:template match="/data:DecorativePoles">
      <data:DecorativePoles>
         <xsl:apply-templates select="data:DecorativePole"/>
      </data:DecorativePoles>
   </xsl:template>

   <xsl:template match="data:DecorativePole">
      <data:DecorativePole>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily"/>
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <xsl:copy-of select="data:PoleHeight" />
         <xsl:copy-of select="data:DecorativePoleType" />
         <xsl:copy-of select="data:Material" />
         <xsl:copy-of select="data:TotalForeignAttachments" />
         <xsl:copy-of select="data:Phasing" />
         <xsl:copy-of select="data:SiteId" />
         <xsl:copy-of select="data:SiteEnergizeStatus" />
         <xsl:copy-of select="data:SiteAddress" />
         <xsl:copy-of select="data:Luminaires" />
      </data:DecorativePole>
   </xsl:template>

   <xsl:template match="/data:AerialWires">
      <data:AerialWires>
         <xsl:apply-templates select="data:AerialWire"/>
      </data:AerialWires>
   </xsl:template>

   <xsl:template match="data:AerialWire">
      <data:AerialWire>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily"/>
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <!-- TODO:  Aerial Wire -->
      </data:AerialWire>
   </xsl:template>


   <xsl:template match="/data:Luminaires">
      <data:Luminaires>
         <xsl:apply-templates select="data:Luminaire"/>
      </data:Luminaires>
   </xsl:template>

   <xsl:template match="data:Luminaire">
      <data:Luminaire>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily"/>
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <xsl:copy-of select="data:Manufacturer"/>
         <xsl:copy-of select="data:ControlType" />
         <xsl:copy-of select="data:LampType" />
         <xsl:copy-of select="data:NominalVoltagePP" />
         <xsl:copy-of select="data:NominalVoltagePN" />
         <xsl:copy-of select="data:PowerConsumption" />
         <xsl:copy-of select="data:LightLumens" />
         <xsl:copy-of select="data:SiteId"/>
         <xsl:copy-of select="data:SiteEnergizeStatus"/>
         <xsl:copy-of select="data:SiteAddress"/>
         <xsl:copy-of select="data:Poles" />
         <xsl:copy-of select="data:DecorativePoles" />
      </data:Luminaire>
   </xsl:template>

   <xsl:template match="/data:Vaults">
      <data:Vaults>
         <xsl:apply-templates select="data:Vault"/>
      </data:Vaults>
   </xsl:template>
   
   <xsl:template match="data:Vault">
      <data:Vault>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <xsl:copy-of select="data:FiberOptics"/>
         <xsl:copy-of select="data:VaultType"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
         <xsl:copy-of select="data:Transformers"/>
         <xsl:copy-of select="data:Cabinets"/>
      </data:Vault>
   </xsl:template>

   <xsl:template match="/data:AerialSwitches">
      <data:AerialSwitches>
         <xsl:apply-templates select="data:AerialSwitch"/>
      </data:AerialSwitches>
   </xsl:template>
   
   <xsl:template match="data:AerialSwitch">
      <data:AerialSwitch>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>
         
         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>
         
         <xsl:copy-of select="data:AerialSwitchType"/>
         <xsl:copy-of select="data:NormalStatus"/>
         <xsl:copy-of select="data:Phasing"/>
         <xsl:copy-of select="data:Mounting"/>
         <xsl:copy-of select="data:VoltageRating"/>
         <xsl:copy-of select="data:ContinuousAmpRating"/>
         <xsl:copy-of select="data:FuseUnits"/>
         <xsl:copy-of select="data:SwitchUnits"/>
         <xsl:copy-of select="data:SwitchSize"/>
         <xsl:copy-of select="data:LoadBreak"/>
         <xsl:copy-of select="data:VendorName"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
         <xsl:copy-of select="data:Poles"/>
         <xsl:copy-of select="data:CircuitTieIndicator"/>
         <xsl:copy-of select="data:Grouping"/>
      </data:AerialSwitch>
   </xsl:template>

   <operation name="PublishManholes">
      <input message="tns:PublishManholesRequest"/>
   </operation>
   <xsl:template match="/data:Manholes">
      <data:Manholes>
         <xsl:apply-templates select="data:Manhole"/>
      </data:Manholes>
   </xsl:template>

   <xsl:template match="data:Manhole">
      <data:Manhole>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <xsl:copy-of select="data:ManholeType"/>
         <xsl:copy-of select="data:Usage"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
      </data:Manhole>
   </xsl:template>


   <operation name="PublishHandholes">
      <input message="tns:PublishHandholesRequest"/>
   </operation>

   <xsl:template match="/data:Handholes">
      <data:Handholes>
         <xsl:apply-templates select="data:Handhole"/>
      </data:Handholes>
   </xsl:template>

   <!-- TODO:  Confirm that we are copying the correct properties over -->
   <xsl:template match="data:Handhole">
      <data:Handhole>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:AssetType"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <xsl:copy-of select="data:HandholeType"/>
         <xsl:copy-of select="data:Usage"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
      </data:Handhole>
   </xsl:template>

   <xsl:template match="/data:Transformers">
      <data:Transformers>
         <xsl:apply-templates select="data:Transformer"/>
      </data:Transformers>
   </xsl:template>
   
   <xsl:template match="data:Transformer">
      <data:Transformer>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <xsl:copy-of select="data:Category"/>
         <xsl:copy-of select="data:BankConfiguration"/>
         <xsl:copy-of select="data:ServiceIPPIndicator"/>
         <xsl:copy-of select="data:SpecialLoading"/>
         <xsl:copy-of select="data:TransformerType"/>
         <xsl:copy-of select="data:DemandPoints"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
         <xsl:copy-of select="data:Poles"/>
          <xsl:copy-of select="data:TransPoles"/>
         <xsl:copy-of select="data:TransStructures"/>
        <xsl:copy-of select="data:Pads"/>
         <xsl:copy-of select="data:Vaults"/>
      </data:Transformer>
   </xsl:template>

   <xsl:template match="/data:Cabinets">
      <data:Cabinets>
         <xsl:apply-templates select="data:Cabinet"/>
      </data:Cabinets>
   </xsl:template>
   
   <xsl:template match="data:Cabinet">
      <data:Cabinet>
         <xsl:variable name="uuid" select="data:UUID"/>
         <xsl:copy-of select="data:UUID"/>
         <xsl:copy-of select="data:ID"/>
         <xsl:copy-of select="data:OwnerType"/>
         <xsl:copy-of select="data:OwnerName"/>
         <xsl:copy-of select="data:GeoLocation"/>
         <xsl:copy-of select="data:StartDate"/>
         <xsl:copy-of select="data:Circuits"/>
         <xsl:copy-of select="data:SourceStatus"/>
         <xsl:copy-of select="data:SourceType"/>
         <xsl:copy-of select="data:MultiFamily" />
         <xsl:copy-of select="data:PreviousAsset"/>
         <xsl:copy-of select="data:ProcessedDate"/>

         <data:ErrorCode>-1</data:ErrorCode>
         <data:ErrorText>Timeout</data:ErrorText>

         <xsl:copy-of select="data:LiveFrontIndicator"/>
         <xsl:copy-of select="data:CabinetType"/>
         <xsl:copy-of select="data:WorkOrderNumber"/>
         <xsl:copy-of select="data:Pads"/>
      </data:Cabinet>
   </xsl:template>
   
</xsl:stylesheet>
