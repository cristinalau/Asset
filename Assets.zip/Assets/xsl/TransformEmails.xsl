<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing"
                xmlns:ns1="http://schemas.microsoft.com/2003/10/Serialization/"
                xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20"
                xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/"
                xmlns:bpel="http://docs.oasis-open.org/wsbpel/2.0/process/executable"
                xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:wsa10="http://www.w3.org/2005/08/addressing"
                xmlns:bpm="http://xmlns.oracle.com/bpmn20/extensions"
                xmlns:soap12="http://schemas.xmlsoap.org/wsdl/soap12/"
                xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/"
                xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/"
                xmlns:mime="http://schemas.xmlsoap.org/wsdl/mime/" xmlns:ora="http://schemas.oracle.com/xpath/extension"
                xmlns:wsx="http://schemas.xmlsoap.org/ws/2004/09/mex"
                xmlns:socket="http://www.oracle.com/XSL/Transform/java/oracle.tip.adapter.socket.ProtocolTranslator"
                xmlns:wsap="http://schemas.xmlsoap.org/ws/2004/08/addressing/policy"
                xmlns:wsaw="http://www.w3.org/2006/05/addressing/wsdl" xmlns:data="urn:epcor:as:ivara:ws:Data"
                xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:common="urn:epcor:as:Common"
                xmlns:mhdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.mediator.service.common.functions.MediatorExtnFunction"
                xmlns:tns="urn:epcor:as:ivara:ws:AssetService:Mediator"
                xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc"
                xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue"
                xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath"
                xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype"
                xmlns:med="http://schemas.oracle.com/mediator/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath"
                xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy"
                xmlns:xdk="http://schemas.oracle.com/bpel/extension/xpath/function/xdk"
                xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions"
                xmlns:msc="http://schemas.microsoft.com/ws/2005/12/wsdl/contract"
                xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:bpmn="http://schemas.oracle.com/bpm/xpath"
                xmlns:wsam="http://www.w3.org/2007/05/addressing/metadata"
                xmlns:ldap="http://schemas.oracle.com/xpath/extension/ldap"
                exclude-result-prefixes="xsi xsl soap12 soap mime data types tns plnk xsd wsa ns1 wsa10 ns2 soapenc wsdl wsx wsap wsaw wsp msc wsu wsam xp20 bpws bpel bpm ora socket mhdr oraext dvm hwf med ids xdk xref bpmn ldap common">

    <xsl:param name="processControl"/>
    <xsl:param name="environmentControl"/>
    <xsl:param name="identityControl"/>
    <xsl:param name="allAssets"/>

    <xsl:template match="/data:AssetLoads">
        <data:AssetsNotificationGroup>
            <data:Assignee>
                <xsl:value-of select="$identityControl/common:identityControl/common:group4Bus"/>
            </data:Assignee>
            <xsl:copy-of select="."/>
            <data:EmailSubject>
                <xsl:value-of
                        select="concat('Ivara Interface ',$processControl/common:processControl/common:interface,' Requires Actions')"/>
            </data:EmailSubject>
            <data:EmailBody>
                &lt;style media="screen" type="text/css">

                .epcorHFTable
                {
                background:#D3E4E5;
                color:#66a3d3;
                border : 1px solid;
                border-color: grey;
                border-collapse:collapse;
                font: normal 12px verdana, arial, helvetica, sans-serif;
                }

                .epcorHFTable tr td
                {
                color:#363636;
                padding: 3px 5px;
                margin: 3px;
                border : 1px solid;
                border-color: grey;
                }

                .epcorHFTable tr th
                {
                padding: 3px 5px;
                margin: 3px;
                background-color: #87B4D9;
                color: black;
                border : 1px solid;
                border-color: grey;
                }

                &lt;/style>
                Hi,

                &lt;br/>

                The interface is suspended because there are more than expected items being deleted from EO. Please
                investigate and confirm the action.

                &lt;br/>
                &lt;br/>
                &lt;table class="epcorHFTable">
                &lt;tr>
                &lt;th>Asset Type&lt;/th>
                &lt;th>Source Activity&lt;/th>
                &lt;th>Total Number&lt;/th>
                &lt;/tr>

                <xsl:for-each select="data:AssetLoad">

                    &lt;tr> &lt;td>
                    <xsl:value-of select="data:Name"/>
                    &lt;/td> &lt;td>
                    <xsl:value-of select="data:SourceType"/>
                    &lt;/td> &lt;td>
                    <xsl:value-of select="data:Number"/>
                    &lt;/td> &lt;/tr>

                </xsl:for-each>
                &lt;/table>
                &lt;br/>

                <xsl:value-of
                        select="concat('Access this task in the &lt;a href=&quot;',$environmentControl/common:environmentControl/common:worklistURL,'&quot;>Worklist Application&lt;/a>')"/>
            </data:EmailBody>
        </data:AssetsNotificationGroup>
    </xsl:template>

    <xsl:template match="/data:AssetsNotificationGroup">
        <data:AssetsNotificationGroup>
            <xsl:copy-of select="data:Assignee"/>
            <xsl:copy-of select="data:Assets"/>
            <data:EmailSubject>
                <xsl:value-of
                        select="concat('Ivara Interface ',$processControl/common:processControl/common:interface,'(',$environmentControl/common:environmentControl/common:instanceId,') has failed records.')"/>
            </data:EmailSubject>
            <data:EmailBody>
                &lt;style media="screen" type="text/css">

                .epcorHFTable
                {
                background:#D3E4E5;
                color:#66a3d3;
                border : 1px solid;
                border-color: grey;
                border-collapse:collapse;
                font: normal 12px verdana, arial, helvetica, sans-serif;
                }

                .epcorHFTable tr td
                {
                color:#363636;
                padding: 3px 5px;
                margin: 3px;
                border : 1px solid;
                border-color: grey;
                }

                .epcorHFTable tr th
                {
                padding: 3px 5px;
                margin: 3px;
                background-color: #87B4D9;
                color: black;
                border : 1px solid;
                border-color: grey;
                }

                &lt;/style>
                Hi,

                &lt;br/>
                &lt;br/>

                The
                <xsl:value-of select="$processControl/common:processControl/common:interface"/> failed with the
                following details. If you have any concerns, please contact IT support.

                &lt;br/>
                &lt;br/>
                &lt;table class="epcorHFTable">
                &lt;tr>
                &lt;th>Asset Type&lt;/th>
                &lt;th>Count &lt;/th>
                &lt;/tr>


                &lt;tr> &lt;td>
                <xsl:value-of select="string('Pole')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Pole'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('TransPole')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='TransPole'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('TransStructure')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='TransStructure'])"/>
                &lt;/td> &lt;/tr>


                &lt;tr> &lt;td>
                <xsl:value-of select="string('Pad')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Pad'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('Pedestal')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Pedestal'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('DecorativePole')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='DecorativePole'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('AerialWire')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='AerialWire'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('Luminaire')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Luminaire'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('Vault')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Vault'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('Manhole')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Manhole'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('Handhole')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Handhole'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('AerialSwitch')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='AerialSwitch'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('Transformer')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Transformer'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('Cabinet')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Cabinet'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('Conductor')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Conductor'])"/>
                &lt;/td> &lt;/tr>

                &lt;tr> &lt;td>
                <xsl:value-of select="string('Cable')"/>
                &lt;/td> &lt;td>
                <xsl:value-of select="count(data:Assets/data:Asset[data:AssetType='Cable'])"/>
                &lt;/td> &lt;/tr>


                &lt;/table>
                &lt;br/>

                <xsl:value-of
                        select="concat('Access this task in the &lt;a href=&quot;',$environmentControl/common:environmentControl/common:worklistURL,'&quot;>Worklist Application&lt;/a>')"/>
            </data:EmailBody>
        </data:AssetsNotificationGroup>
    </xsl:template>

    <xsl:template match="data:AssetTriggerSet">
        <data:AssetsNotificationGroup>
            <data:Assignee>
                <xsl:value-of select="$identityControl/common:identityControl/common:group4Bus"/>
            </data:Assignee>

            <data:EmailSubject>
                <xsl:value-of
                        select="concat('Ivara Interface ',$processControl/common:processControl/common:interface,' has incomplete EO assets files.')"/>
            </data:EmailSubject>
            <data:EmailBody>
                &lt;style media="screen" type="text/css">

                .epcorHFTable
                {
                background:#D3E4E5;
                color:#66a3d3;
                border : 1px solid;
                border-color: grey;
                border-collapse:collapse;
                font: normal 12px verdana, arial, helvetica, sans-serif;
                }

                .epcorHFTable tr td
                {
                color:#363636;
                padding: 3px 5px;
                margin: 3px;
                border : 1px solid;
                border-color: grey;
                }

                .epcorHFTable tr th
                {
                padding: 3px 5px;
                margin: 3px;
                background-color: #87B4D9;
                color: black;
                border : 1px solid;
                border-color: grey;
                }

                &lt;/style>
                Hi,

                &lt;br/>

                The interface failed to proceed because the EO asset file is incomplete. If you have any concerns,
                please contact IT support.

                &lt;br/>
                &lt;br/>
                &lt;table class="epcorHFTable">
                &lt;tr>
                &lt;th>Asset Type&lt;/th>
                &lt;th>File Name&lt;/th>
                &lt;/tr>

                <xsl:for-each select="data:AssetTriggers/data:AssetTrigger">

                    &lt;tr> &lt;td>
                    <xsl:value-of select="data:Name"/>
                    &lt;/td> &lt;td>
                    <xsl:value-of select="data:FileName"/>
                    &lt;/td> &lt;/tr>

                </xsl:for-each>
                &lt;/table>
                &lt;br/>

                <xsl:value-of
                        select="concat('Access this task in the &lt;a href=&quot;',$environmentControl/common:environmentControl/common:worklistURL,'&quot;>Worklist Application&lt;/a>')"/>
            </data:EmailBody>
        </data:AssetsNotificationGroup>
    </xsl:template>

</xsl:stylesheet>
