<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:ns1="http://schemas.microsoft.com/2003/10/Serialization/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:bpel="http://docs.oasis-open.org/wsbpel/2.0/process/executable" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:wsa10="http://www.w3.org/2005/08/addressing" xmlns:bpm="http://xmlns.oracle.com/bpmn20/extensions" xmlns:soap12="http://schemas.xmlsoap.org/wsdl/soap12/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:mime="http://schemas.xmlsoap.org/wsdl/mime/" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:wsx="http://schemas.xmlsoap.org/ws/2004/09/mex" xmlns:socket="http://www.oracle.com/XSL/Transform/java/oracle.tip.adapter.socket.ProtocolTranslator" xmlns:wsap="http://schemas.xmlsoap.org/ws/2004/08/addressing/policy" xmlns:wsaw="http://www.w3.org/2006/05/addressing/wsdl" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:common="urn:epcor:as:Common" xmlns:mhdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.mediator.service.common.functions.MediatorExtnFunction" xmlns:tns="urn:epcor:as:ivara:ws:AssetService:Mediator" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype" xmlns:med="http://schemas.oracle.com/mediator/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns0="urn:epcor:as:ivara:ws:AssetService" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy" xmlns:xdk="http://schemas.oracle.com/bpel/extension/xpath/function/xdk" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:msc="http://schemas.microsoft.com/ws/2005/12/wsdl/contract" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:bpmn="http://schemas.oracle.com/bpm/xpath" xmlns:wsam="http://www.w3.org/2007/05/addressing/metadata" xmlns:ldap="http://schemas.oracle.com/xpath/extension/ldap" exclude-result-prefixes="xsi xsl soap12 soap mime data types tns plnk xsd wsa ns1 wsa10 ns2 soapenc wsdl wsx wsap wsaw ns0 wsp msc wsu wsam xp20 bpws bpel bpm ora socket mhdr oraext dvm hwf med ids xdk xref bpmn ldap common">
   
       <xsl:template match="/data:AssetsNotificationGroup">
          <data:AssetReprocessSet>
            <xsl:apply-templates select="data:Assets"/>
          </data:AssetReprocessSet>
       </xsl:template>
       
       <xsl:template match="data:Assets">
       <xsl:if test="count(data:Asset[data:AssetType='Pole'])>0">
            <data:Poles>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='Pole'">
                        <data:Pole>
                            <xsl:copy-of select="*"/>
                        </data:Pole>
                    </xsl:if>
                </xsl:for-each>
            </data:Poles>
        </xsl:if>

		      <xsl:if test="count(data:Asset[data:AssetType='TransPole'])>0">
            <data:TransPoles>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='TransPole'">
                        <data:TransPole>
                            <xsl:copy-of select="*"/>
                        </data:TransPole>
                    </xsl:if>
                </xsl:for-each>
            </data:TransPoles>
        </xsl:if>
		
		   <xsl:if test="count(data:Asset[data:AssetType='TransStructure'])>0">
            <data:TransStructures>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='TransStructure'">
                        <data:TransStructure>
                            <xsl:copy-of select="*"/>
                        </data:TransStructure>
                    </xsl:if>
                </xsl:for-each>
            </data:TransStructures>
        </xsl:if>
		
        <xsl:if test="count(data:Asset[data:AssetType='Pad'])>0">
            <data:Pads>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='Pad'">
                        <data:Pad>
                            <xsl:copy-of select="*"/>
                        </data:Pad>
                    </xsl:if>
                </xsl:for-each>
            </data:Pads>
        </xsl:if>
           <xsl:if test="count(data:Asset[data:AssetType='Pedestal'])>0">
               <data:Pedestals>
                   <xsl:for-each select="data:Asset">
                       <xsl:if test="data:AssetType='Pedestal'">
                           <data:Pedestal>
                               <xsl:copy-of select="*"/>
                           </data:Pedestal>
                       </xsl:if>
                   </xsl:for-each>
               </data:Pedestals>
           </xsl:if>
           <xsl:if test="count(data:Asset[data:AssetType='DecorativePole'])>0">
               <data:DecorativePoles>
                   <xsl:for-each select="data:Asset">
                       <xsl:if test="data:AssetType='DecorativePole'">
                           <data:DecorativePole>
                               <xsl:copy-of select="*"/>
                           </data:DecorativePole>
                       </xsl:if>
                   </xsl:for-each>
               </data:DecorativePoles>
           </xsl:if>
           <xsl:if test="count(data:Asset[data:AssetType='AerialWire'])>0">
               <data:AerialWires>
                   <xsl:for-each select="data:Asset">
                       <xsl:if test="data:AssetType='AerialWire'">
                           <data:AerialWire>
                               <xsl:copy-of select="*"/>
                           </data:AerialWire>
                       </xsl:if>
                   </xsl:for-each>
               </data:AerialWires>
           </xsl:if>
           <xsl:if test="count(data:Asset[data:AssetType='Luminaire'])>0">
               <data:Luminaires>
                   <xsl:for-each select="data:Asset">
                       <xsl:if test="data:AssetType='Luminaire'">
                           <data:Luminaire>
                               <xsl:copy-of select="*"/>
                           </data:Luminaire>
                       </xsl:if>
                   </xsl:for-each>
               </data:Luminaires>
           </xsl:if>
        <xsl:if test="count(data:Asset[data:AssetType='Vault'])>0">
            <data:Vaults>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='Vault'">
                        <data:Vault>
                            <xsl:copy-of select="*"/>
                        </data:Vault>
                    </xsl:if>
                </xsl:for-each>
            </data:Vaults>
        </xsl:if>
           <xsl:if test="count(data:Asset[data:AssetType='Manhole'])>0">
               <data:Manholes>
                   <xsl:for-each select="data:Asset">
                       <xsl:if test="data:AssetType='Manhole'">
                           <data:Manhole>
                               <xsl:copy-of select="*"/>
                           </data:Manhole>
                       </xsl:if>
                   </xsl:for-each>
               </data:Manholes>
           </xsl:if>
           <xsl:if test="count(data:Asset[data:AssetType='Handhole'])>0">
               <data:Handholes>
                   <xsl:for-each select="data:Asset">
                       <xsl:if test="data:AssetType='Handhole'">
                           <data:Handhole>
                               <xsl:copy-of select="*"/>
                           </data:Handhole>
                       </xsl:if>
                   </xsl:for-each>
               </data:Handholes>
           </xsl:if>
        <xsl:if test="count(data:Asset[data:AssetType='AerialSwitch'])>0">
            <data:AerialSwitches>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='AerialSwitch'">
                        <data:AerialSwitch>
                            <xsl:copy-of select="*"/>
                        </data:AerialSwitch>
                    </xsl:if>
                </xsl:for-each>
            </data:AerialSwitches>
        </xsl:if>
        <xsl:if test="count(data:Asset[data:AssetType='Transformer'])>0">
            <data:Transformers>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='Transformer'">
                        <data:Transformer>
                            <xsl:copy-of select="*"/>
                        </data:Transformer>
                    </xsl:if>
                </xsl:for-each>
            </data:Transformers>
        </xsl:if>
        <xsl:if test="count(data:Asset[data:AssetType='Cabinet'])>0">
            <data:Cabinets>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='Cabinet'">
                        <data:Cabinet>
                            <xsl:copy-of select="*"/>
                        </data:Cabinet>
                    </xsl:if>
                </xsl:for-each>
            </data:Cabinets>
        </xsl:if>
      <xsl:if test="count(data:Asset[data:AssetType='Conductor'])>0">
            <data:Conductors>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='Conductor'">
                        <data:Conductor>
                            <xsl:copy-of select="*"/>
                        </data:Conductor>
                    </xsl:if>
                </xsl:for-each>
            </data:Conductors>
        </xsl:if>
        <xsl:if test="count(data:Asset[data:AssetType='Cable'])>0">
            <data:Cables>
                <xsl:for-each select="data:Asset">
                    <xsl:if test="data:AssetType='Cable'">
                        <data:Cable>
                            <xsl:copy-of select="*"/>
                        </data:Cable>
                    </xsl:if>
                </xsl:for-each>
            </data:Cables>
        </xsl:if>


        </xsl:template>
       
    </xsl:stylesheet>
