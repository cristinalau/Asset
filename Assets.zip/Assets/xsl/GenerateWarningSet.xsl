<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:ns1="http://schemas.microsoft.com/2003/10/Serialization/" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:bpws="http://schemas.xmlsoap.org/ws/2003/03/business-process/" xmlns:bpel="http://docs.oasis-open.org/wsbpel/2.0/process/executable" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:wsa10="http://www.w3.org/2005/08/addressing" xmlns:bpm="http://xmlns.oracle.com/bpmn20/extensions" xmlns:soap12="http://schemas.xmlsoap.org/wsdl/soap12/" xmlns:soapenc="http://schemas.xmlsoap.org/soap/encoding/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:mime="http://schemas.xmlsoap.org/wsdl/mime/" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:wsx="http://schemas.xmlsoap.org/ws/2004/09/mex" xmlns:socket="http://www.oracle.com/XSL/Transform/java/oracle.tip.adapter.socket.ProtocolTranslator" xmlns:wsap="http://schemas.xmlsoap.org/ws/2004/08/addressing/policy" xmlns:wsaw="http://www.w3.org/2006/05/addressing/wsdl" xmlns:data="urn:epcor:as:ivara:ws:Data" xmlns:types="urn:epcor:as:ivara:ws:Types" xmlns:common="urn:epcor:as:Common" xmlns:mhdr="http://www.oracle.com/XSL/Transform/java/oracle.tip.mediator.service.common.functions.MediatorExtnFunction" xmlns:tns="urn:epcor:as:ivara:ws:AssetService:Mediator" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:hwf="http://xmlns.oracle.com/bpel/workflow/xpath" xmlns:plnk="http://docs.oasis-open.org/wsbpel/2.0/plnktype" xmlns:med="http://schemas.oracle.com/mediator/xpath" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ids="http://xmlns.oracle.com/bpel/services/IdentityService/xpath" xmlns:wsp="http://schemas.xmlsoap.org/ws/2004/09/policy" xmlns:xdk="http://schemas.oracle.com/bpel/extension/xpath/function/xdk" xmlns:xref="http://www.oracle.com/XSL/Transform/java/oracle.tip.xref.xpath.XRefXPathFunctions" xmlns:msc="http://schemas.microsoft.com/ws/2005/12/wsdl/contract" xmlns:wsu="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:bpmn="http://schemas.oracle.com/bpm/xpath" xmlns:wsam="http://www.w3.org/2007/05/addressing/metadata" xmlns:ldap="http://schemas.oracle.com/xpath/extension/ldap" exclude-result-prefixes="xsi xsl soap12 soap mime data types tns plnk xsd wsa ns1 wsa10 ns2 soapenc wsdl wsx wsap wsaw wsp msc wsu wsam xp20 bpws bpel bpm ora socket mhdr oraext dvm hwf med ids xdk xref bpmn ldap common">
                
  <xsl:param name="allAssets"/>
  <xsl:param name="processControl"/>
  
  <xsl:key name="lookupSite" match="/data:NotificationGroups/data:NotificationGroup" use="data:Assignee"/>
  <xsl:key name="lookupDistinct" match="/data:NotificationGroups/data:NotificationGroup/data:Assignee" use="."/>

  <xsl:template match="/data:NotificationGroups">
    <data:AssetsNotificationGroups>
      <xsl:apply-templates select="data:NotificationGroup/data:Assignee"/>
    </data:AssetsNotificationGroups>
  </xsl:template>
  
  <xsl:template match="data:Assignee">
    <xsl:if test="generate-id() = generate-id(key('lookupDistinct',normalize-space(.)))">
      <data:AssetsNotificationGroup>
        <xsl:variable name="group" select="."/>
        <data:Assignee>
          <xsl:value-of select="."/>
        </data:Assignee>
        <data:Assets>
          <xsl:apply-templates select="key('lookupSite',$group)"/>
        </data:Assets>
      </data:AssetsNotificationGroup>
    </xsl:if>
  </xsl:template>
  
  <xsl:template match="data:NotificationGroup">
    <xsl:variable name="site" select="data:Site"/>
          <xsl:for-each select="$allAssets">
               <xsl:for-each select="data:AssetReprocessSet/data:Poles/data:Pole">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:TransPoles/data:TransPole">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Cables/data:Cable">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Conductors/data:Conductor">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Pads/data:Pad">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Pedestals/data:Pedestal">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:DecorativePoles/data:DecorativePole">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:AerialWires/data:AerialWire">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Luminaires/data:Luminaire">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Vaults/data:Vault">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Manholes/data:Manhole">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Handholes/data:Handhole">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:AerialSwitches/data:AerialSwitch">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Transformers/data:Transformer">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
               <xsl:for-each select="data:AssetReprocessSet/data:Cabinets/data:Cabinet">
                    <xsl:if test="data:Site = $site and data:ErrorCode=0 and boolean(string(data:ErrorText))">
                         <data:Asset>
                              <xsl:copy-of select="data:UUID"/>
                              <xsl:copy-of select="data:ID"/>
                              <xsl:copy-of select="data:AssetType"/>
                              <xsl:copy-of select="data:ErrorText"/>
                         </data:Asset>
                    </xsl:if>
               </xsl:for-each>
          </xsl:for-each>
     </xsl:template>

</xsl:stylesheet>
